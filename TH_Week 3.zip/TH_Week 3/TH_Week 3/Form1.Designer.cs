﻿namespace TH_Week_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_ucbank = new System.Windows.Forms.Label();
            this.lb_usn = new System.Windows.Forms.Label();
            this.tb_Username = new System.Windows.Forms.TextBox();
            this.lb_psw = new System.Windows.Forms.Label();
            this.tb_Password = new System.Windows.Forms.TextBox();
            this.btn_Login = new System.Windows.Forms.Button();
            this.btn_Register = new System.Windows.Forms.Button();
            this.panel_login = new System.Windows.Forms.Panel();
            this.lb_usnR = new System.Windows.Forms.Label();
            this.tb_usnR = new System.Windows.Forms.TextBox();
            this.lb_pswR = new System.Windows.Forms.Label();
            this.tb_pswR = new System.Windows.Forms.TextBox();
            this.btn_RegisterR = new System.Windows.Forms.Button();
            this.panel_register = new System.Windows.Forms.Panel();
            this.btn_logOut = new System.Windows.Forms.Button();
            this.lb_blnc = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.btn_Deposit = new System.Windows.Forms.Button();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.panel_Main = new System.Windows.Forms.Panel();
            this.panel_Deposit = new System.Windows.Forms.Panel();
            this.tb_Deposit = new System.Windows.Forms.TextBox();
            this.btn_deposit2 = new System.Windows.Forms.Button();
            this.lb_input = new System.Windows.Forms.Label();
            this.btn_outDep = new System.Windows.Forms.Button();
            this.panel_Withdrawal = new System.Windows.Forms.Panel();
            this.lb_withdrawal = new System.Windows.Forms.Label();
            this.lb_BalanceW = new System.Windows.Forms.Label();
            this.lb_balance2 = new System.Windows.Forms.Label();
            this.tb_withdrawal = new System.Windows.Forms.TextBox();
            this.btn_withdraw2 = new System.Windows.Forms.Button();
            this.btn_outWith = new System.Windows.Forms.Button();
            this.panel_login.SuspendLayout();
            this.panel_register.SuspendLayout();
            this.panel_Main.SuspendLayout();
            this.panel_Deposit.SuspendLayout();
            this.panel_Withdrawal.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_ucbank
            // 
            this.lb_ucbank.AutoSize = true;
            this.lb_ucbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbank.Location = new System.Drawing.Point(151, 74);
            this.lb_ucbank.Name = "lb_ucbank";
            this.lb_ucbank.Size = new System.Drawing.Size(306, 76);
            this.lb_ucbank.TabIndex = 0;
            this.lb_ucbank.Text = "UC Bank";
            // 
            // lb_usn
            // 
            this.lb_usn.AutoSize = true;
            this.lb_usn.Location = new System.Drawing.Point(67, 29);
            this.lb_usn.Name = "lb_usn";
            this.lb_usn.Size = new System.Drawing.Size(152, 32);
            this.lb_usn.TabIndex = 2;
            this.lb_usn.Text = "Username:";
            // 
            // tb_Username
            // 
            this.tb_Username.Location = new System.Drawing.Point(256, 29);
            this.tb_Username.Name = "tb_Username";
            this.tb_Username.Size = new System.Drawing.Size(208, 38);
            this.tb_Username.TabIndex = 3;
            // 
            // lb_psw
            // 
            this.lb_psw.AutoSize = true;
            this.lb_psw.Location = new System.Drawing.Point(73, 106);
            this.lb_psw.Name = "lb_psw";
            this.lb_psw.Size = new System.Drawing.Size(146, 32);
            this.lb_psw.TabIndex = 4;
            this.lb_psw.Text = "Password:";
            // 
            // tb_Password
            // 
            this.tb_Password.Location = new System.Drawing.Point(256, 103);
            this.tb_Password.Name = "tb_Password";
            this.tb_Password.Size = new System.Drawing.Size(208, 38);
            this.tb_Password.TabIndex = 5;
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(164, 186);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(171, 52);
            this.btn_Login.TabIndex = 6;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // btn_Register
            // 
            this.btn_Register.Location = new System.Drawing.Point(164, 268);
            this.btn_Register.Name = "btn_Register";
            this.btn_Register.Size = new System.Drawing.Size(171, 52);
            this.btn_Register.TabIndex = 7;
            this.btn_Register.Text = "Register";
            this.btn_Register.UseVisualStyleBackColor = true;
            this.btn_Register.Click += new System.EventHandler(this.btn_Register_Click);
            // 
            // panel_login
            // 
            this.panel_login.Controls.Add(this.lb_usn);
            this.panel_login.Controls.Add(this.btn_Register);
            this.panel_login.Controls.Add(this.tb_Username);
            this.panel_login.Controls.Add(this.btn_Login);
            this.panel_login.Controls.Add(this.lb_psw);
            this.panel_login.Controls.Add(this.tb_Password);
            this.panel_login.Location = new System.Drawing.Point(38, 169);
            this.panel_login.Name = "panel_login";
            this.panel_login.Size = new System.Drawing.Size(534, 350);
            this.panel_login.TabIndex = 8;
            // 
            // lb_usnR
            // 
            this.lb_usnR.AutoSize = true;
            this.lb_usnR.Location = new System.Drawing.Point(44, 61);
            this.lb_usnR.Name = "lb_usnR";
            this.lb_usnR.Size = new System.Drawing.Size(152, 32);
            this.lb_usnR.TabIndex = 8;
            this.lb_usnR.Text = "Username:";
            // 
            // tb_usnR
            // 
            this.tb_usnR.Location = new System.Drawing.Point(233, 61);
            this.tb_usnR.Name = "tb_usnR";
            this.tb_usnR.Size = new System.Drawing.Size(208, 38);
            this.tb_usnR.TabIndex = 9;
            // 
            // lb_pswR
            // 
            this.lb_pswR.AutoSize = true;
            this.lb_pswR.Location = new System.Drawing.Point(50, 138);
            this.lb_pswR.Name = "lb_pswR";
            this.lb_pswR.Size = new System.Drawing.Size(146, 32);
            this.lb_pswR.TabIndex = 10;
            this.lb_pswR.Text = "Password:";
            // 
            // tb_pswR
            // 
            this.tb_pswR.Location = new System.Drawing.Point(233, 135);
            this.tb_pswR.Name = "tb_pswR";
            this.tb_pswR.Size = new System.Drawing.Size(208, 38);
            this.tb_pswR.TabIndex = 11;
            // 
            // btn_RegisterR
            // 
            this.btn_RegisterR.Location = new System.Drawing.Point(160, 211);
            this.btn_RegisterR.Name = "btn_RegisterR";
            this.btn_RegisterR.Size = new System.Drawing.Size(171, 52);
            this.btn_RegisterR.TabIndex = 8;
            this.btn_RegisterR.Text = "Register";
            this.btn_RegisterR.UseVisualStyleBackColor = true;
            this.btn_RegisterR.Click += new System.EventHandler(this.btn_RegisterR_Click);
            // 
            // panel_register
            // 
            this.panel_register.Controls.Add(this.btn_RegisterR);
            this.panel_register.Controls.Add(this.lb_usnR);
            this.panel_register.Controls.Add(this.tb_usnR);
            this.panel_register.Controls.Add(this.lb_pswR);
            this.panel_register.Controls.Add(this.tb_pswR);
            this.panel_register.Location = new System.Drawing.Point(74, 149);
            this.panel_register.Name = "panel_register";
            this.panel_register.Size = new System.Drawing.Size(495, 340);
            this.panel_register.TabIndex = 12;
            // 
            // btn_logOut
            // 
            this.btn_logOut.Location = new System.Drawing.Point(297, 32);
            this.btn_logOut.Name = "btn_logOut";
            this.btn_logOut.Size = new System.Drawing.Size(171, 52);
            this.btn_logOut.TabIndex = 8;
            this.btn_logOut.Text = "Log Out";
            this.btn_logOut.UseVisualStyleBackColor = true;
            this.btn_logOut.Click += new System.EventHandler(this.btn_logOut_Click);
            // 
            // lb_blnc
            // 
            this.lb_blnc.AutoSize = true;
            this.lb_blnc.Location = new System.Drawing.Point(31, 160);
            this.lb_blnc.Name = "lb_blnc";
            this.lb_blnc.Size = new System.Drawing.Size(118, 32);
            this.lb_blnc.TabIndex = 13;
            this.lb_blnc.Text = "Balance";
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balance.Location = new System.Drawing.Point(181, 154);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(159, 46);
            this.lb_balance.TabIndex = 14;
            this.lb_balance.Text = "Rp 0,00";
            // 
            // btn_Deposit
            // 
            this.btn_Deposit.Location = new System.Drawing.Point(164, 233);
            this.btn_Deposit.Name = "btn_Deposit";
            this.btn_Deposit.Size = new System.Drawing.Size(171, 52);
            this.btn_Deposit.TabIndex = 15;
            this.btn_Deposit.Text = "Deposit";
            this.btn_Deposit.UseVisualStyleBackColor = true;
            this.btn_Deposit.Click += new System.EventHandler(this.btn_Deposit_Click);
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(164, 312);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(171, 52);
            this.btn_Withdraw.TabIndex = 16;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            this.btn_Withdraw.Click += new System.EventHandler(this.btn_Withdraw_Click);
            // 
            // panel_Main
            // 
            this.panel_Main.Controls.Add(this.btn_Withdraw);
            this.panel_Main.Controls.Add(this.btn_Deposit);
            this.panel_Main.Controls.Add(this.lb_balance);
            this.panel_Main.Controls.Add(this.lb_blnc);
            this.panel_Main.Controls.Add(this.btn_logOut);
            this.panel_Main.Location = new System.Drawing.Point(55, 153);
            this.panel_Main.Name = "panel_Main";
            this.panel_Main.Size = new System.Drawing.Size(983, 402);
            this.panel_Main.TabIndex = 17;
            // 
            // panel_Deposit
            // 
            this.panel_Deposit.Controls.Add(this.tb_Deposit);
            this.panel_Deposit.Controls.Add(this.btn_deposit2);
            this.panel_Deposit.Controls.Add(this.lb_input);
            this.panel_Deposit.Controls.Add(this.btn_outDep);
            this.panel_Deposit.Location = new System.Drawing.Point(58, 149);
            this.panel_Deposit.Name = "panel_Deposit";
            this.panel_Deposit.Size = new System.Drawing.Size(500, 402);
            this.panel_Deposit.TabIndex = 18;
            // 
            // tb_Deposit
            // 
            this.tb_Deposit.Location = new System.Drawing.Point(144, 172);
            this.tb_Deposit.Name = "tb_Deposit";
            this.tb_Deposit.Size = new System.Drawing.Size(208, 38);
            this.tb_Deposit.TabIndex = 12;
            // 
            // btn_deposit2
            // 
            this.btn_deposit2.Location = new System.Drawing.Point(164, 233);
            this.btn_deposit2.Name = "btn_deposit2";
            this.btn_deposit2.Size = new System.Drawing.Size(171, 52);
            this.btn_deposit2.TabIndex = 15;
            this.btn_deposit2.Text = "Deposit";
            this.btn_deposit2.UseVisualStyleBackColor = true;
            this.btn_deposit2.Click += new System.EventHandler(this.btn_deposit2_Click);
            // 
            // lb_input
            // 
            this.lb_input.AutoSize = true;
            this.lb_input.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.lb_input.Location = new System.Drawing.Point(114, 125);
            this.lb_input.Name = "lb_input";
            this.lb_input.Size = new System.Drawing.Size(283, 31);
            this.lb_input.TabIndex = 13;
            this.lb_input.Text = "Input Deposit Amount:";
            // 
            // btn_outDep
            // 
            this.btn_outDep.Location = new System.Drawing.Point(297, 32);
            this.btn_outDep.Name = "btn_outDep";
            this.btn_outDep.Size = new System.Drawing.Size(171, 52);
            this.btn_outDep.TabIndex = 8;
            this.btn_outDep.Text = "Log Out";
            this.btn_outDep.UseVisualStyleBackColor = true;
            this.btn_outDep.Click += new System.EventHandler(this.btn_outDep_Click);
            // 
            // panel_Withdrawal
            // 
            this.panel_Withdrawal.Controls.Add(this.lb_withdrawal);
            this.panel_Withdrawal.Controls.Add(this.lb_BalanceW);
            this.panel_Withdrawal.Controls.Add(this.lb_balance2);
            this.panel_Withdrawal.Controls.Add(this.tb_withdrawal);
            this.panel_Withdrawal.Controls.Add(this.btn_withdraw2);
            this.panel_Withdrawal.Controls.Add(this.btn_outWith);
            this.panel_Withdrawal.Location = new System.Drawing.Point(41, 152);
            this.panel_Withdrawal.Name = "panel_Withdrawal";
            this.panel_Withdrawal.Size = new System.Drawing.Size(1000, 402);
            this.panel_Withdrawal.TabIndex = 19;
            // 
            // lb_withdrawal
            // 
            this.lb_withdrawal.AutoSize = true;
            this.lb_withdrawal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.lb_withdrawal.Location = new System.Drawing.Point(107, 189);
            this.lb_withdrawal.Name = "lb_withdrawal";
            this.lb_withdrawal.Size = new System.Drawing.Size(309, 31);
            this.lb_withdrawal.TabIndex = 16;
            this.lb_withdrawal.Text = "Input Witdrawal Amount:";
            // 
            // lb_BalanceW
            // 
            this.lb_BalanceW.AutoSize = true;
            this.lb_BalanceW.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_BalanceW.Location = new System.Drawing.Point(222, 130);
            this.lb_BalanceW.Name = "lb_BalanceW";
            this.lb_BalanceW.Size = new System.Drawing.Size(159, 46);
            this.lb_BalanceW.TabIndex = 18;
            this.lb_BalanceW.Text = "Rp 0,00";
            // 
            // lb_balance2
            // 
            this.lb_balance2.AutoSize = true;
            this.lb_balance2.Location = new System.Drawing.Point(90, 136);
            this.lb_balance2.Name = "lb_balance2";
            this.lb_balance2.Size = new System.Drawing.Size(118, 32);
            this.lb_balance2.TabIndex = 17;
            this.lb_balance2.Text = "Balance";
            // 
            // tb_withdrawal
            // 
            this.tb_withdrawal.Location = new System.Drawing.Point(144, 233);
            this.tb_withdrawal.Name = "tb_withdrawal";
            this.tb_withdrawal.Size = new System.Drawing.Size(208, 38);
            this.tb_withdrawal.TabIndex = 12;
            // 
            // btn_withdraw2
            // 
            this.btn_withdraw2.Location = new System.Drawing.Point(164, 294);
            this.btn_withdraw2.Name = "btn_withdraw2";
            this.btn_withdraw2.Size = new System.Drawing.Size(171, 52);
            this.btn_withdraw2.TabIndex = 15;
            this.btn_withdraw2.Text = "Withdraw";
            this.btn_withdraw2.UseVisualStyleBackColor = true;
            this.btn_withdraw2.Click += new System.EventHandler(this.btn_withdraw2_Click);
            // 
            // btn_outWith
            // 
            this.btn_outWith.Location = new System.Drawing.Point(297, 32);
            this.btn_outWith.Name = "btn_outWith";
            this.btn_outWith.Size = new System.Drawing.Size(171, 52);
            this.btn_outWith.TabIndex = 8;
            this.btn_outWith.Text = "Log Out";
            this.btn_outWith.UseVisualStyleBackColor = true;
            this.btn_outWith.Click += new System.EventHandler(this.btn_outWith_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2032, 1304);
            this.Controls.Add(this.panel_Withdrawal);
            this.Controls.Add(this.panel_Deposit);
            this.Controls.Add(this.panel_Main);
            this.Controls.Add(this.panel_register);
            this.Controls.Add(this.panel_login);
            this.Controls.Add(this.lb_ucbank);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_login.ResumeLayout(false);
            this.panel_login.PerformLayout();
            this.panel_register.ResumeLayout(false);
            this.panel_register.PerformLayout();
            this.panel_Main.ResumeLayout(false);
            this.panel_Main.PerformLayout();
            this.panel_Deposit.ResumeLayout(false);
            this.panel_Deposit.PerformLayout();
            this.panel_Withdrawal.ResumeLayout(false);
            this.panel_Withdrawal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_ucbank;
        private System.Windows.Forms.Label lb_usn;
        private System.Windows.Forms.TextBox tb_Username;
        private System.Windows.Forms.Label lb_psw;
        private System.Windows.Forms.TextBox tb_Password;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.Button btn_Register;
        private System.Windows.Forms.Panel panel_login;
        private System.Windows.Forms.Label lb_usnR;
        private System.Windows.Forms.TextBox tb_usnR;
        private System.Windows.Forms.Label lb_pswR;
        private System.Windows.Forms.TextBox tb_pswR;
        private System.Windows.Forms.Button btn_RegisterR;
        private System.Windows.Forms.Panel panel_register;
        private System.Windows.Forms.Button btn_logOut;
        private System.Windows.Forms.Label lb_blnc;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Button btn_Deposit;
        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Panel panel_Main;
        private System.Windows.Forms.Panel panel_Deposit;
        private System.Windows.Forms.TextBox tb_Deposit;
        private System.Windows.Forms.Button btn_deposit2;
        private System.Windows.Forms.Label lb_input;
        private System.Windows.Forms.Button btn_outDep;
        private System.Windows.Forms.Panel panel_Withdrawal;
        private System.Windows.Forms.TextBox tb_withdrawal;
        private System.Windows.Forms.Button btn_withdraw2;
        private System.Windows.Forms.Button btn_outWith;
        private System.Windows.Forms.Label lb_withdrawal;
        private System.Windows.Forms.Label lb_BalanceW;
        private System.Windows.Forms.Label lb_balance2;
    }
}


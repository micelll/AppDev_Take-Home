﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_Week_3
{
    public partial class Form1 : Form
    {
        List <string> username = new List <string> ();
        List <string> password = new List <string> ();
        List<int> balance = new List <int> ();

        public int indexU = 0;
        public int indexP = 0;
        public int indexUR = 0;
        public int indexPR = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Register_Click(object sender, EventArgs e)
        {
            panel_login.Visible = false;
            panel_register.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel_register.Visible = false;
            panel_Main.Visible = false;
            panel_Deposit.Visible = false;
            panel_Withdrawal.Visible = false;
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            if (username.Count == 0)
            {
                MessageBox.Show("Username and Password not found!");
                tb_Username.Clear();
                tb_Password.Clear();
            }
            else if (!username.Contains(tb_Username.Text) || !password.Contains(tb_Password.Text))
            {
                MessageBox.Show("Username and Password not found!");
                tb_Username.Clear();
                tb_Password.Clear();
            }
            else if (username.Contains(tb_Username.Text) && password.Contains(tb_Password.Text))
            {
                for (int i = 0; i < username.Count; i++)
                {
                    if (tb_Username.Text == username[i])
                    {
                        indexU = i;
                    }
                    if (tb_Password.Text == password[i])
                    {
                        indexP = i;
                    }
                }

                if (indexU != indexP)
                {
                    MessageBox.Show("Username and Password not found!");
                    tb_Username.Clear();
                    tb_Password.Clear();
                }
                else
                {
                    MessageBox.Show("Login Successful");
                    tb_Username.Clear();
                    tb_Password.Clear();

                    panel_login.Visible = false;
                    panel_Main.Visible = true;
                    lb_balance.Text = String.Format("Rp. {0:N}", balance[indexU]);
                }
            }
        }

        private void btn_RegisterR_Click(object sender, EventArgs e)
        {
            if (tb_usnR.Text.Length != 0 && tb_pswR.Text.Length != 0)
            {
                if (username.Contains(tb_usnR.Text))
                {
                    MessageBox.Show("Username has been used");
                    tb_usnR.Clear();
                    tb_pswR.Clear();
                }
                else
                {
                    username.Add(tb_usnR.Text);
                    password.Add(tb_pswR.Text);

                    for (int i = 0; i < username.Count; i++)
                    {
                        if (tb_usnR.Text == username[i])
                        {
                            indexUR = i;
                        }
                        if (tb_pswR.Text == password[i])
                        {
                            indexPR = i;
                        }
                    }

                    MessageBox.Show("Register Successful");
                    addBalanceList(username, balance);

                    panel_register.Visible = false;
                    panel_login.Visible = true;

                    tb_usnR.Clear();
                    tb_pswR.Clear();
                }
            }
            else if (tb_usnR.Text.Length == 0 || tb_pswR.Text.Length == 0)
            {
                MessageBox.Show("Enter your username and password!");
                tb_usnR.Clear();
                tb_pswR.Clear();
            }

            if (tb_Username.Text.Length != 0 && tb_Password.Text.Length != 0)
            {
                tb_Username.Clear();
                tb_Password.Clear();
            }
        }

        private void btn_logOut_Click(object sender, EventArgs e)
        {
            panel_Main.Visible = false;
            panel_login.Visible = true;
        }

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            panel_Main.Visible = false;
            panel_Deposit.Visible = true;
        }

        private void btn_outDep_Click(object sender, EventArgs e)
        {
            panel_Deposit.Visible = false;
            panel_login.Visible = true;
        }

        private void btn_deposit2_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(tb_Deposit.Text) <= 0)
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
                tb_Deposit.Clear();
                panel_Deposit.Visible = false;
                panel_Main.Visible = true;
            }
            else if (Convert.ToInt32(tb_Deposit.Text) > 0)
            {
                balance[indexU] += Convert.ToInt32(tb_Deposit.Text);
                MessageBox.Show("Succesfully Add Deposit ");
                lb_balance.Text = String.Format("Rp. {0:N}", balance[indexU]);
                tb_Deposit.Clear();

                panel_Deposit.Visible = false;
                panel_Main.Visible = true;
            }
        }

        static void addBalanceList(List<string> username, List<int> balance)
        {
            for (int i = 0; i < username.Count; i++)
            {
                balance.Add(0);
            }
        }

        private void btn_outWith_Click(object sender, EventArgs e)
        {
            panel_Withdrawal.Visible = false;
            panel_login.Visible = true;
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            panel_Main.Visible = false;
            panel_Withdrawal.Visible = true;

            lb_BalanceW.Text = String.Format("Rp. {0:N}", balance[indexU]);
        }

        private void btn_withdraw2_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(tb_withdrawal.Text) > balance[indexU])
            {
                MessageBox.Show("Withdraw failed. Not enough balance.");
                tb_withdrawal.Clear();
                panel_Withdrawal.Visible = false;
                panel_Main.Visible = true;
            }
            else if (Convert.ToInt32(tb_withdrawal.Text) <= 0)
            {
                MessageBox.Show("Withdrawal Amount Can't be Less Than 1");
                tb_withdrawal.Clear();
                panel_Withdrawal.Visible = false;
                panel_Main.Visible = true;
            }
            else
            {
                balance[indexU] -= Convert.ToInt32(tb_withdrawal.Text); ;
                MessageBox.Show("Succesfully Withdraw");
                lb_balance.Text = String.Format("Rp. {0:N}", balance[indexU]);
                tb_withdrawal.Clear();

                panel_Withdrawal.Visible = false;
                panel_Main.Visible = true;
            }
        }
    }
}

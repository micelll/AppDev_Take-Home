﻿namespace TH_Week_5
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_product = new System.Windows.Forms.Label();
            this.btn_All = new System.Windows.Forms.Button();
            this.btn_Filter = new System.Windows.Forms.Button();
            this.cb_Filter = new System.Windows.Forms.ComboBox();
            this.dgv_tampil = new System.Windows.Forms.DataGridView();
            this.lb_Details = new System.Windows.Forms.Label();
            this.lb_Nama = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_Nama = new System.Windows.Forms.TextBox();
            this.tb_Harga = new System.Windows.Forms.TextBox();
            this.tb_Stock = new System.Windows.Forms.TextBox();
            this.cb_Category = new System.Windows.Forms.ComboBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.btn_Edit = new System.Windows.Forms.Button();
            this.lb_Category = new System.Windows.Forms.Label();
            this.dgv_Category = new System.Windows.Forms.DataGridView();
            this.lb_namaC = new System.Windows.Forms.Label();
            this.tb_namaC = new System.Windows.Forms.TextBox();
            this.btn_AddC = new System.Windows.Forms.Button();
            this.btn_RemoveC = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_tampil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Category)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_product
            // 
            this.lb_product.AutoSize = true;
            this.lb_product.Font = new System.Drawing.Font("Times New Roman", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_product.Location = new System.Drawing.Point(80, 73);
            this.lb_product.Name = "lb_product";
            this.lb_product.Size = new System.Drawing.Size(184, 53);
            this.lb_product.TabIndex = 0;
            this.lb_product.Text = "Product";
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(452, 144);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(99, 47);
            this.btn_All.TabIndex = 1;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // btn_Filter
            // 
            this.btn_Filter.Location = new System.Drawing.Point(575, 144);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(99, 47);
            this.btn_Filter.TabIndex = 2;
            this.btn_Filter.Text = "Filter:";
            this.btn_Filter.UseVisualStyleBackColor = true;
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // cb_Filter
            // 
            this.cb_Filter.FormattingEnabled = true;
            this.cb_Filter.Location = new System.Drawing.Point(702, 146);
            this.cb_Filter.Name = "cb_Filter";
            this.cb_Filter.Size = new System.Drawing.Size(202, 39);
            this.cb_Filter.TabIndex = 3;
            this.cb_Filter.SelectedIndexChanged += new System.EventHandler(this.cb_Filter_SelectedIndexChanged);
            // 
            // dgv_tampil
            // 
            this.dgv_tampil.AllowUserToAddRows = false;
            this.dgv_tampil.AllowUserToOrderColumns = true;
            this.dgv_tampil.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_tampil.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_tampil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_tampil.Location = new System.Drawing.Point(89, 208);
            this.dgv_tampil.Name = "dgv_tampil";
            this.dgv_tampil.ReadOnly = true;
            this.dgv_tampil.RowHeadersVisible = false;
            this.dgv_tampil.RowHeadersWidth = 102;
            this.dgv_tampil.RowTemplate.Height = 40;
            this.dgv_tampil.Size = new System.Drawing.Size(815, 573);
            this.dgv_tampil.TabIndex = 4;
            this.dgv_tampil.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgv_tampil_MouseClick);
            // 
            // lb_Details
            // 
            this.lb_Details.AutoSize = true;
            this.lb_Details.Font = new System.Drawing.Font("Times New Roman", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Details.Location = new System.Drawing.Point(89, 820);
            this.lb_Details.Name = "lb_Details";
            this.lb_Details.Size = new System.Drawing.Size(162, 53);
            this.lb_Details.TabIndex = 5;
            this.lb_Details.Text = "Details";
            // 
            // lb_Nama
            // 
            this.lb_Nama.AutoSize = true;
            this.lb_Nama.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Nama.Location = new System.Drawing.Point(89, 892);
            this.lb_Nama.Name = "lb_Nama";
            this.lb_Nama.Size = new System.Drawing.Size(104, 32);
            this.lb_Nama.TabIndex = 6;
            this.lb_Nama.Text = "Nama :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(89, 945);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 32);
            this.label1.TabIndex = 7;
            this.label1.Text = "Category :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(89, 1001);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 32);
            this.label2.TabIndex = 8;
            this.label2.Text = "Harga :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(89, 1057);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 32);
            this.label3.TabIndex = 9;
            this.label3.Text = "Stock :";
            // 
            // tb_Nama
            // 
            this.tb_Nama.Location = new System.Drawing.Point(266, 892);
            this.tb_Nama.Name = "tb_Nama";
            this.tb_Nama.Size = new System.Drawing.Size(638, 38);
            this.tb_Nama.TabIndex = 10;
            // 
            // tb_Harga
            // 
            this.tb_Harga.Location = new System.Drawing.Point(266, 1001);
            this.tb_Harga.Name = "tb_Harga";
            this.tb_Harga.Size = new System.Drawing.Size(213, 38);
            this.tb_Harga.TabIndex = 11;
            this.tb_Harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Harga_KeyPress);
            // 
            // tb_Stock
            // 
            this.tb_Stock.Location = new System.Drawing.Point(266, 1057);
            this.tb_Stock.Name = "tb_Stock";
            this.tb_Stock.Size = new System.Drawing.Size(213, 38);
            this.tb_Stock.TabIndex = 12;
            this.tb_Stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Stock_KeyPress);
            // 
            // cb_Category
            // 
            this.cb_Category.FormattingEnabled = true;
            this.cb_Category.Location = new System.Drawing.Point(266, 945);
            this.cb_Category.Name = "cb_Category";
            this.cb_Category.Size = new System.Drawing.Size(213, 39);
            this.cb_Category.TabIndex = 13;
            // 
            // btn_Add
            // 
            this.btn_Add.BackColor = System.Drawing.Color.SpringGreen;
            this.btn_Add.Location = new System.Drawing.Point(510, 980);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(158, 97);
            this.btn_Add.TabIndex = 14;
            this.btn_Add.Text = "Add Product";
            this.btn_Add.UseVisualStyleBackColor = false;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Remove
            // 
            this.btn_Remove.BackColor = System.Drawing.Color.Red;
            this.btn_Remove.Location = new System.Drawing.Point(842, 980);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(172, 97);
            this.btn_Remove.TabIndex = 15;
            this.btn_Remove.Text = "Remove Product";
            this.btn_Remove.UseVisualStyleBackColor = false;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // btn_Edit
            // 
            this.btn_Edit.BackColor = System.Drawing.Color.Yellow;
            this.btn_Edit.Location = new System.Drawing.Point(671, 980);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(171, 97);
            this.btn_Edit.TabIndex = 16;
            this.btn_Edit.Text = "Edit Product";
            this.btn_Edit.UseVisualStyleBackColor = false;
            this.btn_Edit.Click += new System.EventHandler(this.btn_Edit_Click);
            // 
            // lb_Category
            // 
            this.lb_Category.AutoSize = true;
            this.lb_Category.Font = new System.Drawing.Font("Times New Roman", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Category.Location = new System.Drawing.Point(993, 73);
            this.lb_Category.Name = "lb_Category";
            this.lb_Category.Size = new System.Drawing.Size(210, 53);
            this.lb_Category.TabIndex = 17;
            this.lb_Category.Text = "Category";
            // 
            // dgv_Category
            // 
            this.dgv_Category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_Category.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_Category.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Category.Location = new System.Drawing.Point(1002, 208);
            this.dgv_Category.Name = "dgv_Category";
            this.dgv_Category.ReadOnly = true;
            this.dgv_Category.RowHeadersVisible = false;
            this.dgv_Category.RowHeadersWidth = 102;
            this.dgv_Category.RowTemplate.Height = 40;
            this.dgv_Category.ShowCellErrors = false;
            this.dgv_Category.Size = new System.Drawing.Size(469, 421);
            this.dgv_Category.TabIndex = 18;
            this.dgv_Category.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgv_Category_MouseClick);
            // 
            // lb_namaC
            // 
            this.lb_namaC.AutoSize = true;
            this.lb_namaC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_namaC.Location = new System.Drawing.Point(996, 676);
            this.lb_namaC.Name = "lb_namaC";
            this.lb_namaC.Size = new System.Drawing.Size(104, 32);
            this.lb_namaC.TabIndex = 19;
            this.lb_namaC.Text = "Nama :";
            // 
            // tb_namaC
            // 
            this.tb_namaC.Location = new System.Drawing.Point(1122, 673);
            this.tb_namaC.Name = "tb_namaC";
            this.tb_namaC.Size = new System.Drawing.Size(349, 38);
            this.tb_namaC.TabIndex = 20;
            // 
            // btn_AddC
            // 
            this.btn_AddC.BackColor = System.Drawing.Color.SpringGreen;
            this.btn_AddC.Location = new System.Drawing.Point(1122, 739);
            this.btn_AddC.Name = "btn_AddC";
            this.btn_AddC.Size = new System.Drawing.Size(162, 97);
            this.btn_AddC.TabIndex = 21;
            this.btn_AddC.Text = "Add Category";
            this.btn_AddC.UseVisualStyleBackColor = false;
            this.btn_AddC.Click += new System.EventHandler(this.btn_AddC_Click);
            // 
            // btn_RemoveC
            // 
            this.btn_RemoveC.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveC.Location = new System.Drawing.Point(1299, 739);
            this.btn_RemoveC.Name = "btn_RemoveC";
            this.btn_RemoveC.Size = new System.Drawing.Size(172, 97);
            this.btn_RemoveC.TabIndex = 22;
            this.btn_RemoveC.Text = "Remove Category";
            this.btn_RemoveC.UseVisualStyleBackColor = false;
            this.btn_RemoveC.Click += new System.EventHandler(this.btn_RemoveC_Click);
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1766, 1160);
            this.Controls.Add(this.btn_RemoveC);
            this.Controls.Add(this.btn_AddC);
            this.Controls.Add(this.tb_namaC);
            this.Controls.Add(this.lb_namaC);
            this.Controls.Add(this.dgv_Category);
            this.Controls.Add(this.lb_Category);
            this.Controls.Add(this.btn_Edit);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.cb_Category);
            this.Controls.Add(this.tb_Stock);
            this.Controls.Add(this.tb_Harga);
            this.Controls.Add(this.tb_Nama);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_Nama);
            this.Controls.Add(this.lb_Details);
            this.Controls.Add(this.dgv_tampil);
            this.Controls.Add(this.cb_Filter);
            this.Controls.Add(this.btn_Filter);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.lb_product);
            this.Name = "Form_Main";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form_Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_tampil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_product;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.Button btn_Filter;
        private System.Windows.Forms.ComboBox cb_Filter;
        private System.Windows.Forms.DataGridView dgv_tampil;
        private System.Windows.Forms.Label lb_Details;
        private System.Windows.Forms.Label lb_Nama;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_Nama;
        private System.Windows.Forms.TextBox tb_Harga;
        private System.Windows.Forms.TextBox tb_Stock;
        private System.Windows.Forms.ComboBox cb_Category;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.Button btn_Edit;
        private System.Windows.Forms.Label lb_Category;
        private System.Windows.Forms.DataGridView dgv_Category;
        private System.Windows.Forms.Label lb_namaC;
        private System.Windows.Forms.TextBox tb_namaC;
        private System.Windows.Forms.Button btn_AddC;
        private System.Windows.Forms.Button btn_RemoveC;
    }
}


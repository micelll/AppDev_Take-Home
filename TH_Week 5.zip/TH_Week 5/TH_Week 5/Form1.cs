﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_Week_5
{
    public partial class Form_Main : Form
    {
        DataTable dtProdukSimpan = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();
        public Form_Main()
        {
            InitializeComponent();
        }
        
        private void Form_Main_Load(object sender, EventArgs e)
        {
            cb_Filter.Enabled = false;

            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");
            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", 100000, 10, "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", 70000, 20, "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", 75000, 16, "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", 82000, 26, "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", 90000, 5, "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", 60000, 11, "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-Blink", 1000000, 1, "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", 50000, 8, "C2");

            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");
            dtProdukTampil.Rows.Add("J001", "Jas Hitam", 100000, 10, "C1");
            dtProdukTampil.Rows.Add("T001", "T-Shirt Black Pink", 70000, 20, "C2");
            dtProdukTampil.Rows.Add("T002", "T-Shirt Obsessive", 75000, 16, "C2");
            dtProdukTampil.Rows.Add("R001", "Rok Mini", 82000, 26, "C3");
            dtProdukTampil.Rows.Add("J002", "Jeans Biru", 90000, 5, "C4");
            dtProdukTampil.Rows.Add("C001", "Celana Pendek Coklat", 60000, 11, "C4");
            dtProdukTampil.Rows.Add("C002","Cawat Blink-Blink", 1000000, 1, "C5");
            dtProdukTampil.Rows.Add("R002", "Rocca Shirt", 50000, 8, "C2");
            dgv_tampil.DataSource = dtProdukTampil;

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");
            dgv_Category.DataSource = dtCategory;

            dgv_Category.ClearSelection();
            dgv_tampil.ClearSelection();

            foreach (DataRow row in dtCategory.Rows)
            {
                string itemCategories = row["Nama Category"].ToString();
                cb_Filter.Items.Add(itemCategories);
                cb_Category.Items.Add(itemCategories);
            }
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            cb_Filter.Enabled = true;
        }

        private void btn_AddC_Click(object sender, EventArgs e)
        {
            bool cekAdd = false;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][1].ToString() == tb_namaC.Text)
                {
                    cekAdd = true;
                    MessageBox.Show("Ada nama yang sama");
                }
            }
            if (tb_namaC.Text == "")
            {
                MessageBox.Show("Masukkan nama category terlebih dahulu");
            }
            else if (!cekAdd)
            {
                int index = dtCategory.Rows.Count - 1;
                string category = dtCategory.Rows[index][0].ToString();
                string nomer = category.Substring(1);
                int addNum = Convert.ToInt32(nomer) + 1;
                string addCategory = "C" + addNum;
                dtCategory.Rows.Add(addCategory, tb_namaC.Text);
                cb_Filter.Items.Add(tb_namaC.Text);
                cb_Category.Items.Add(tb_namaC.Text);
            }
            tb_namaC.Clear();
        }

        private void btn_RemoveC_Click(object sender, EventArgs e)
        {
            if (dgv_Category.SelectedCells.Count == 0)
            {
                MessageBox.Show("Belum ada yang diselect");
            }
            else
            {
                DataGridViewRow dgvr = dgv_Category.CurrentRow;
                int selectedIndex = dgvr.Index;
                string namaCategory = dtCategory.Rows[selectedIndex][1].ToString();

                List<DataRow> remove = new List<DataRow>();
                foreach (DataRow row in dtProdukTampil.Rows)
                {
                    if (dtCategory.Rows[selectedIndex][0].ToString() == row["ID Category"].ToString())
                    {
                        remove.Add(row);
                    }
                }
                foreach (DataRow row in remove)
                {
                    dtProdukTampil.Rows.Remove(row);
                }

                for (int i = 0; i < cb_Filter.Items.Count; i++)
                {
                    if (cb_Filter.Items[i].ToString() == namaCategory && cb_Category.Items[i].ToString() == namaCategory)
                    {
                        cb_Filter.Items.Remove(cb_Filter.Items[i]);
                        cb_Category.Items.Remove(cb_Category.Items[i]);
                        break;
                    }
                }

                if (dgv_tampil.DataSource != dtProdukTampil)
                {
                    dgv_tampil.DataSource = dtProdukTampil;
                }
                dgv_Category.Rows.Remove(dgvr);
                tb_namaC.Clear();
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            bool cekk = false;
            for (int i = 0; i < dtProdukTampil.Rows.Count; i++)
            {
                if (dtProdukTampil.Rows[i][1].ToString() == tb_Nama.Text)
                {
                    cekk = true;
                    MessageBox.Show("Ada nama yang sama");
                }
            }
            if (tb_Nama.Text == "" || cb_Category.SelectedItem == null || tb_Harga.Text == "" || tb_Stock.Text == "")
            {
                MessageBox.Show("Input yang lengkap yaa");
            }
            else if (!cekk)
            {
                int indexCategory = 0;
                string idProduct = "";
                string input = tb_Nama.Text.ToUpper();
                int angka = 0;
                foreach (DataRow row in dtProdukTampil.Rows)
                {
                    if (row["ID Product"].ToString().ToUpper()[0] == input[0])
                    {
                        int num = Convert.ToInt32(row["ID Product"].ToString().Substring(1));
                        if (num > angka)
                        {
                            angka = num;
                        }
                    }
                }

                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (cb_Category.SelectedItem.ToString() == dtCategory.Rows[i][1].ToString())
                    {
                        indexCategory = i;
                        break;
                    }
                }
                foreach (DataRow row in dtCategory.Rows)
                {
                    if (cb_Category.SelectedItem.ToString() == row["Nama Category"].ToString())
                    {
                        int id = angka + 1;
                        if (id < 10)
                        {
                            idProduct = input[0] + "00" + id.ToString();
                        }
                        else if ( id < 100)
                        {
                            idProduct = input[0] + "0" + id.ToString();
                        }
                        else
                        {
                            idProduct = input[0] + id.ToString();
                        }
                    }
                }
                string idCategory = dtCategory.Rows[indexCategory][0].ToString();
                dtProdukTampil.Rows.Add(idProduct, tb_Nama.Text, tb_Harga.Text, tb_Stock.Text, idCategory);

                if (dgv_tampil.DataSource != dtProdukTampil)
                {
                    dgv_tampil.DataSource = dtProdukTampil;
                }
            }
            tb_Nama.Clear();
            cb_Category.SelectedItem = null;
            tb_Harga.Clear();
            tb_Stock.Clear();
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            if (dgv_tampil.SelectedCells.Count == 0)
            {
                MessageBox.Show("Belum ada yang diselect");
            }
            else
            {
                if (dgv_tampil.DataSource == dtProdukTampil)
                {
                    DataGridViewRow dgvr = dgv_tampil.CurrentRow;
                    dgv_tampil.Rows.Remove(dgvr);
                }
                else
                {
                    DataGridViewRow dgvr = dgv_tampil.CurrentRow;
                    foreach (DataRow row in dtProdukTampil.Rows)
                    {
                        if (dgvr.Cells[0].Value.ToString() == row["ID Product"].ToString())
                        {
                            dtProdukTampil.Rows.Remove(row);
                            break;
                        }
                    }
                    dgv_tampil.Rows.Remove(dgvr);
                }

                tb_Nama.Clear();
                cb_Category.SelectedItem = null;
                tb_Harga.Clear();
                tb_Stock.Clear();
            }
        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            cb_Filter.SelectedItem = null;
            cb_Filter.Enabled = false;
            dgv_tampil.DataSource = dtProdukTampil;
        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            if (dgv_tampil.SelectedCells.Count == 0)
            {
                MessageBox.Show("Belum ada yang diselect");
            }
            else
            {
                if (tb_Nama.Text == "" || cb_Category.SelectedItem == null || tb_Harga.Text == "" || tb_Stock.Text == "")
                {
                    MessageBox.Show("Ada yang kosong :)");
                    tb_Nama.Clear();
                    cb_Category.SelectedItem = null;
                    tb_Harga.Clear();
                    tb_Stock.Clear();
                }
                else
                {
                    int newCatIndex = 0;
                    string newName = tb_Nama.Text;
                    int newHarga = Convert.ToInt32(tb_Harga.Text);
                    int newStock = Convert.ToInt32(tb_Stock.Text);

                    string newCategory = cb_Category.SelectedItem.ToString();
                    for (int i = 0; i < dtCategory.Rows.Count; i++)
                    {
                        if (dtCategory.Rows[i][1].ToString() == newCategory)
                        {
                            newCatIndex = i;
                            break;
                        }
                    }

                    string newIDCategory = dtCategory.Rows[newCatIndex][0].ToString();
                    int dtIndex = dgv_tampil.CurrentRow.Index;
                    if (newStock == 0)
                    {
                        dtProdukTampil.Rows.RemoveAt(dtIndex);
                    }
                    else
                    {
                        dtProdukTampil.Rows[dtIndex][1] = newName;
                        dtProdukTampil.Rows[dtIndex][2] = newHarga;
                        dtProdukTampil.Rows[dtIndex][3] = newStock;
                        dtProdukTampil.Rows[dtIndex][4] = newIDCategory;
                    }

                    tb_Nama.Clear();
                    cb_Category.SelectedItem = null;
                    tb_Harga.Clear();
                    tb_Stock.Clear();

                    if (dgv_tampil.DataSource != dtProdukTampil)
                    {
                        dgv_tampil.DataSource = dtProdukTampil;
                        cb_Filter.Enabled = false;
                    }
                }
            }
        }

        private void cb_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_Filter.SelectedItem != null)
            {
                int indexFilter = 0;
                dtProdukSimpan.Clear();
                string filter = cb_Filter.SelectedItem.ToString();
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i][1].ToString() == filter)
                    {
                        indexFilter = i;
                        break;
                    }
                }
                string filterID = dtCategory.Rows[indexFilter][0].ToString();

                for (int i = 0; i < dtProdukTampil.Rows.Count; i++)
                {
                    if (dtProdukTampil.Rows[i][4].ToString() == filterID)
                    {
                        string id = dtProdukTampil.Rows[i][0].ToString();
                        string nama = dtProdukTampil.Rows[i][1].ToString();
                        int harga = Convert.ToInt32(dtProdukTampil.Rows[i][2]);
                        int stock = Convert.ToInt32(dtProdukTampil.Rows[i][3]);
                        dtProdukSimpan.Rows.Add(id, nama, harga, stock, filterID);
                    }
                }
                dgv_tampil.DataSource = dtProdukSimpan;
            }
            else
            {

            }
        }

        private void tb_Harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void tb_Stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void dgv_tampil_MouseClick(object sender, MouseEventArgs e)
        {
            int indexCategory = 0;
            DataGridViewRow dgvr = dgv_tampil.CurrentRow;
            tb_Nama.Text = dgvr.Cells[1].Value.ToString();
            tb_Harga.Text = dgvr.Cells[2].Value.ToString();
            tb_Stock.Text = dgvr.Cells[3].Value.ToString();

            string selectCategory = dgvr.Cells[4].Value.ToString();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][0].ToString() == selectCategory)
                {
                    indexCategory = i;
                    break;
                }
            }
            cb_Category.SelectedItem = dtCategory.Rows[indexCategory][1].ToString();
        }

        private void dgv_Category_MouseClick(object sender, MouseEventArgs e)
        {
            DataGridViewRow dgvr = dgv_Category.CurrentRow;
            tb_namaC.Text = dgvr.Cells[1].Value.ToString();
        }
    }
}

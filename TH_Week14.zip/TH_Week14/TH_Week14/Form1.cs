﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace TH_Week14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection connect = new MySqlConnection();
        MySqlCommand command = new MySqlCommand();
        MySqlDataAdapter adapter = new MySqlDataAdapter();

        DataTable dtTeam = new DataTable();
        DataTable dtMatch = new DataTable();
        DataTable dtPlayer = new DataTable();
        DataTable dtIDHome = new DataTable();
        DataTable dtIDAway = new DataTable();

        string query = "";
        private void Form1_Load(object sender, EventArgs e)
        {
            // passwordnya perlu diisi
            connect = new MySqlConnection("server=localhost;uid=root;pwd=;database=premier_league;");
            connect.Open();

            string query = "select team_name from team;";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dtTeam);

            foreach (DataRow row in dtTeam.Rows)
            {
                cb_teamHome.Items.Add(row["team_name"].ToString());
            }

            foreach (DataRow row in dtTeam.Rows)
            {
                cb_teamAway.Items.Add(row["team_name"].ToString());
            }

            cb_type.Items.Add("GO");
            cb_type.Items.Add("GP");
            cb_type.Items.Add("GW");
            cb_type.Items.Add("CR");
            cb_type.Items.Add("CY");
            cb_type.Items.Add("PM");

            connect.Close();
        }

        string teamIDHome;
        string teamIDAway;
        private void cb_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamHome.SelectedItem != null && cb_teamAway.SelectedItem != null)
            {
                cb_team.Items.Clear();
                dtMatch.Clear();
                dtIDAway.Clear();
                dtIDHome.Clear();

                if (cb_teamHome.SelectedItem.ToString() == cb_teamAway.SelectedItem.ToString())
                {
                    MessageBox.Show("Teamnya sama");
                    cb_teamHome.SelectedItem = null;
                    cb_team.Items.Clear();
                }
                else
                {
                    query = "select team_id from team where team_name = '" + cb_teamHome.SelectedItem.ToString() + "';";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtIDHome);

                    teamIDHome = dtIDHome.Rows[0][0].ToString();

                    query = "select team_id from team where team_name = '" + cb_teamAway.SelectedItem.ToString() + "';";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtIDAway);

                    teamIDAway = dtIDAway.Rows[0][0].ToString();

                    cb_team.Items.Add(cb_teamHome.SelectedItem.ToString());
                    cb_team.Items.Add(cb_teamAway.SelectedItem.ToString());
                    query = $"select d.minute as Minute, t.team_name as Team, p.player_name as Player, d.Type as Type from dmatch d join team t on d.team_id = t.team_id join player p on p.player_id = d.player_id join `match` m on m.match_id = d.match_id where m.team_home ='" + teamIDHome + "' and m.team_away = '" + teamIDAway + "' and m.referee_id = 'M002' and m.match_id <= '2016-02-14' and (d.Type = 'GO' or d.Type = 'GP' or d.Type ='GW');";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtMatch);
                    dgv_sepakBola.DataSource = dtMatch;
                    DataTable dtMatchID = new DataTable();
                    dtMatchID.Clear();

                    query = "select match_id from `match` where team_home = '" + teamIDHome + "' and team_away = '" + teamIDAway + "';";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtMatchID);

                    if (dtMatchID.Rows.Count != 0)
                    {
                        tb_matchID.Text = dtMatchID.Rows[0][0].ToString();

                        DataTable dtmatchDate = new DataTable();
                        dtmatchDate.Clear();

                        query = "select match_date from `match` where match_ID = '" + dtMatchID.Rows[0][0].ToString() + "';";
                        command = new MySqlCommand(query, connect);
                        adapter = new MySqlDataAdapter(command);
                        adapter.Fill(dtmatchDate);

                        if (dtmatchDate.Rows.Count != 0)
                        {
                            string date = dtmatchDate.Rows[0][0].ToString();
                            dtp_matchDate.Text = date;
                        }
                    }
                    else
                    {
                        dtp_matchDate.Text = DateTime.Now.ToString();
                        string selectedYear = dtp_matchDate.Value.Year.ToString();
                        tb_matchID.Text = selectedYear + "001";
                    }
                }
            }
        }

        private void cb_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamHome.SelectedItem != null && cb_teamAway.SelectedItem != null)
            {
                cb_team.Items.Clear();
                dtMatch.Clear();
                dtIDAway.Clear();
                dtIDHome.Clear();

                if (cb_teamHome.SelectedItem.ToString() == cb_teamAway.SelectedItem.ToString())
                {
                    MessageBox.Show("Teamnya sama");
                    cb_teamAway.SelectedItem = null;
                    cb_team.Items.Clear();
                }
                else
                {
                    query = "select team_id from team where team_name = '" + cb_teamHome.SelectedItem.ToString() + "';";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtIDHome);

                    teamIDHome = dtIDHome.Rows[0][0].ToString();

                    query = "select team_id from team where team_name = '" + cb_teamAway.SelectedItem.ToString() + "';";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtIDAway);

                    teamIDAway= dtIDAway.Rows[0][0].ToString();

                    cb_team.Items.Add(cb_teamHome.SelectedItem.ToString());
                    cb_team.Items.Add(cb_teamAway.SelectedItem.ToString());

                    query = $"select d.minute as Minute, t.team_name as Team, p.player_name as Player, d.Type as Type from dmatch d join team t on d.team_id = t.team_id join player p on p.player_id = d.player_id join `match` m on m.match_id = d.match_id where m.team_home ='" + teamIDHome + "' and m.team_away = '" + teamIDAway + "' and m.referee_id = 'M002' and m.match_id <= '2016-02-14' and (d.Type = 'GO' or d.Type = 'GP' or d.Type ='GW');";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtMatch);

                    dgv_sepakBola.DataSource = dtMatch;

                    DataTable dtMatchID = new DataTable();
                    dtMatchID.Clear();

                    query = "select match_id from `match` where team_home = '" + teamIDHome + "' and team_away = '" + teamIDAway + "';";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtMatchID);

                    if (dtMatchID.Rows.Count != 0)
                    {
                        tb_matchID.Text = dtMatchID.Rows[0][0].ToString();

                        DataTable dtmatchDate = new DataTable();
                        dtmatchDate.Clear();

                        query = "select match_date from `match` where match_ID = '" + dtMatchID.Rows[0][0].ToString() + "';";
                        command = new MySqlCommand(query, connect);
                        adapter = new MySqlDataAdapter(command);
                        adapter.Fill(dtmatchDate);

                        if (dtmatchDate.Rows.Count != 0)
                        {
                            string date = dtmatchDate.Rows[0][0].ToString();
                            dtp_matchDate.Text = date;
                        }

                    }
                    else
                    {
                        dtp_matchDate.Text = DateTime.Now.ToString();
                        string selectedYear = dtp_matchDate.Value.Year.ToString();
                        tb_matchID.Text = selectedYear + "001";

                    }
                }
            }
        }
        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_team.SelectedIndex != -1)
            {
                if (cb_team.SelectedItem.ToString() == cb_teamHome.SelectedItem.ToString())
                {
                    dtPlayer.Clear();
                    query = "select player_name from player where team_id = '" + teamIDHome + "';";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtPlayer);

                    cb_player.DataSource = dtPlayer;
                    cb_player.DisplayMember = "player_name";
                    cb_player.ValueMember = "player_name";

                    cb_player.SelectedIndex = -1;

                }
                else if (cb_team.SelectedItem.ToString() == cb_teamAway.SelectedItem.ToString())
                {
                    dtPlayer.Clear();
                    query = "select player_name from player where team_id = '" + teamIDAway + "';";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtPlayer);

                    cb_player.DataSource = dtPlayer;
                    cb_player.DisplayMember = "player_name";
                    cb_player.ValueMember = "player_name";

                    cb_player.SelectedIndex = -1;
                }
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tb_minute.Text != "" && cb_team.SelectedItem != null && cb_player.SelectedItem != null && cb_type.SelectedItem != null)
            {
                dtMatch.Rows.Add(tb_minute.Text, cb_team.SelectedItem.ToString(), cb_player.SelectedValue.ToString(), cb_type.SelectedItem.ToString());
                tb_minute.Clear();
                cb_team.SelectedIndex = -1;
                cb_player.SelectedIndex = -1;
                cb_type.SelectedIndex = -1;
            }
            else
            {
                MessageBox.Show("Tidak boleh ada yang kosong!");
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            int index = dgv_sepakBola.CurrentRow.Index;
            dgv_sepakBola.Rows.RemoveAt(index);
        }

        DataTable dtPlayerID = new DataTable();
        int goalHome = 0;
        int goalAway = 0;
        private void btn_insert_Click(object sender, EventArgs e)
        {
            dtPlayerID.Clear();
            DateTime date = dtp_matchDate.Value;
            string mDate = date.ToString("yyyy-MM-dd");


            if (tb_matchID != null && dtMatch.Rows.Count != 0)
            {
                for (int i = 0; i < dtMatch.Rows.Count; i++)
                {
                    if (dtMatch.Rows[i][1].ToString() == cb_teamHome.SelectedItem.ToString())
                    {
                        connect.Open();
                        playerID();

                        query = "insert into dmatch values ('" + tb_matchID.Text + "', " + Convert.ToInt32(dtMatch.Rows[i][0].ToString()) + ", '" + teamIDHome + "', '" + dtPlayerID.Rows[i][0].ToString() + "', '" + dtMatch.Rows[i][3].ToString() + "', '0');";
                        command = new MySqlCommand(query, connect);
                        command.ExecuteNonQuery();
                        connect.Close();
                    }
                    else if (dtMatch.Rows[i][1].ToString() == cb_teamAway.SelectedItem.ToString())
                    {
                        connect.Open();
                        playerID();

                        query = "insert into dmatch values ('" + tb_matchID.Text + "', " + Convert.ToInt32(dtMatch.Rows[i][0].ToString()) + ", '" + teamIDAway + "', '" + dtPlayerID.Rows[i][0].ToString() + "', '" + dtMatch.Rows[i][3].ToString() + "', '0');";
                        command = new MySqlCommand(query, connect);
                        command.ExecuteNonQuery();
                        connect.Close();
                    }
                }
            }
        }
        private void playerID()
        {
            for (int i = 0; i < dtMatch.Rows.Count; i++)
            {
                query = "select player_id from player where player_name = '" + dtMatch.Rows[i][2].ToString() + "';";
                command = new MySqlCommand(query, connect);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtPlayerID);
            }
        }

        private void dtp_matchDate_ValueChanged(object sender, EventArgs e)
        {
            string selectedYear = dtp_matchDate.Value.Year.ToString();
            tb_matchID.Text = selectedYear + "001";
        }
    }
}

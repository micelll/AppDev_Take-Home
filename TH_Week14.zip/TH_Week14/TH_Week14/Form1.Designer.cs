﻿namespace TH_Week14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_insert = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.lb_type = new System.Windows.Forms.Label();
            this.lb_player = new System.Windows.Forms.Label();
            this.lb_team = new System.Windows.Forms.Label();
            this.lb_minute = new System.Windows.Forms.Label();
            this.dgv_sepakBola = new System.Windows.Forms.DataGridView();
            this.dtp_matchDate = new System.Windows.Forms.DateTimePicker();
            this.cb_teamHome = new System.Windows.Forms.ComboBox();
            this.cb_teamAway = new System.Windows.Forms.ComboBox();
            this.lb_teamA = new System.Windows.Forms.Label();
            this.lb_matchDate = new System.Windows.Forms.Label();
            this.lb_teamH = new System.Windows.Forms.Label();
            this.tb_matchID = new System.Windows.Forms.TextBox();
            this.lb_matchID = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_sepakBola)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(385, 604);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(340, 39);
            this.btn_insert.TabIndex = 40;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(924, 448);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(122, 40);
            this.btn_delete.TabIndex = 39;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(786, 448);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(122, 40);
            this.btn_add.TabIndex = 38;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(870, 383);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(205, 33);
            this.cb_type.TabIndex = 37;
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(870, 333);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(205, 33);
            this.cb_player.TabIndex = 36;
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(870, 287);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(205, 33);
            this.cb_team.TabIndex = 35;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(870, 241);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(205, 31);
            this.tb_minute.TabIndex = 34;
            // 
            // lb_type
            // 
            this.lb_type.AutoSize = true;
            this.lb_type.Location = new System.Drawing.Point(781, 383);
            this.lb_type.Name = "lb_type";
            this.lb_type.Size = new System.Drawing.Size(66, 25);
            this.lb_type.TabIndex = 33;
            this.lb_type.Text = "Type:";
            // 
            // lb_player
            // 
            this.lb_player.AutoSize = true;
            this.lb_player.Location = new System.Drawing.Point(781, 333);
            this.lb_player.Name = "lb_player";
            this.lb_player.Size = new System.Drawing.Size(79, 25);
            this.lb_player.TabIndex = 32;
            this.lb_player.Text = "Player:";
            // 
            // lb_team
            // 
            this.lb_team.AutoSize = true;
            this.lb_team.Location = new System.Drawing.Point(781, 287);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(72, 25);
            this.lb_team.TabIndex = 31;
            this.lb_team.Text = "Team:";
            // 
            // lb_minute
            // 
            this.lb_minute.AutoSize = true;
            this.lb_minute.Location = new System.Drawing.Point(781, 241);
            this.lb_minute.Name = "lb_minute";
            this.lb_minute.Size = new System.Drawing.Size(83, 25);
            this.lb_minute.TabIndex = 30;
            this.lb_minute.Text = "Minute:";
            // 
            // dgv_sepakBola
            // 
            this.dgv_sepakBola.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_sepakBola.Location = new System.Drawing.Point(39, 187);
            this.dgv_sepakBola.Name = "dgv_sepakBola";
            this.dgv_sepakBola.RowHeadersWidth = 82;
            this.dgv_sepakBola.RowTemplate.Height = 33;
            this.dgv_sepakBola.Size = new System.Drawing.Size(686, 373);
            this.dgv_sepakBola.TabIndex = 29;
            // 
            // dtp_matchDate
            // 
            this.dtp_matchDate.Location = new System.Drawing.Point(592, 46);
            this.dtp_matchDate.Name = "dtp_matchDate";
            this.dtp_matchDate.Size = new System.Drawing.Size(394, 31);
            this.dtp_matchDate.TabIndex = 28;
            this.dtp_matchDate.ValueChanged += new System.EventHandler(this.dtp_matchDate_ValueChanged);
            // 
            // cb_teamHome
            // 
            this.cb_teamHome.FormattingEnabled = true;
            this.cb_teamHome.Location = new System.Drawing.Point(174, 103);
            this.cb_teamHome.Name = "cb_teamHome";
            this.cb_teamHome.Size = new System.Drawing.Size(233, 33);
            this.cb_teamHome.TabIndex = 27;
            this.cb_teamHome.SelectedIndexChanged += new System.EventHandler(this.cb_teamHome_SelectedIndexChanged);
            // 
            // cb_teamAway
            // 
            this.cb_teamAway.FormattingEnabled = true;
            this.cb_teamAway.Location = new System.Drawing.Point(592, 103);
            this.cb_teamAway.Name = "cb_teamAway";
            this.cb_teamAway.Size = new System.Drawing.Size(233, 33);
            this.cb_teamAway.TabIndex = 26;
            this.cb_teamAway.SelectedIndexChanged += new System.EventHandler(this.cb_teamAway_SelectedIndexChanged);
            // 
            // lb_teamA
            // 
            this.lb_teamA.AutoSize = true;
            this.lb_teamA.Location = new System.Drawing.Point(456, 109);
            this.lb_teamA.Name = "lb_teamA";
            this.lb_teamA.Size = new System.Drawing.Size(130, 25);
            this.lb_teamA.TabIndex = 25;
            this.lb_teamA.Text = "Team Away:";
            // 
            // lb_matchDate
            // 
            this.lb_matchDate.AutoSize = true;
            this.lb_matchDate.Location = new System.Drawing.Point(456, 47);
            this.lb_matchDate.Name = "lb_matchDate";
            this.lb_matchDate.Size = new System.Drawing.Size(128, 25);
            this.lb_matchDate.TabIndex = 24;
            this.lb_matchDate.Text = "Match Date:";
            // 
            // lb_teamH
            // 
            this.lb_teamH.AutoSize = true;
            this.lb_teamH.Location = new System.Drawing.Point(34, 106);
            this.lb_teamH.Name = "lb_teamH";
            this.lb_teamH.Size = new System.Drawing.Size(134, 25);
            this.lb_teamH.TabIndex = 23;
            this.lb_teamH.Text = "Team Home:";
            // 
            // tb_matchID
            // 
            this.tb_matchID.Enabled = false;
            this.tb_matchID.Location = new System.Drawing.Point(174, 47);
            this.tb_matchID.Name = "tb_matchID";
            this.tb_matchID.Size = new System.Drawing.Size(140, 31);
            this.tb_matchID.TabIndex = 22;
            // 
            // lb_matchID
            // 
            this.lb_matchID.AutoSize = true;
            this.lb_matchID.Location = new System.Drawing.Point(34, 50);
            this.lb_matchID.Name = "lb_matchID";
            this.lb_matchID.Size = new System.Drawing.Size(103, 25);
            this.lb_matchID.TabIndex = 21;
            this.lb_matchID.Text = "Match ID:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1205, 848);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.lb_type);
            this.Controls.Add(this.lb_player);
            this.Controls.Add(this.lb_team);
            this.Controls.Add(this.lb_minute);
            this.Controls.Add(this.dgv_sepakBola);
            this.Controls.Add(this.dtp_matchDate);
            this.Controls.Add(this.cb_teamHome);
            this.Controls.Add(this.cb_teamAway);
            this.Controls.Add(this.lb_teamA);
            this.Controls.Add(this.lb_matchDate);
            this.Controls.Add(this.lb_teamH);
            this.Controls.Add(this.tb_matchID);
            this.Controls.Add(this.lb_matchID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_sepakBola)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.Label lb_type;
        private System.Windows.Forms.Label lb_player;
        private System.Windows.Forms.Label lb_team;
        private System.Windows.Forms.Label lb_minute;
        private System.Windows.Forms.DataGridView dgv_sepakBola;
        private System.Windows.Forms.DateTimePicker dtp_matchDate;
        private System.Windows.Forms.ComboBox cb_teamHome;
        private System.Windows.Forms.ComboBox cb_teamAway;
        private System.Windows.Forms.Label lb_teamA;
        private System.Windows.Forms.Label lb_matchDate;
        private System.Windows.Forms.Label lb_teamH;
        private System.Windows.Forms.TextBox tb_matchID;
        private System.Windows.Forms.Label lb_matchID;
    }
}


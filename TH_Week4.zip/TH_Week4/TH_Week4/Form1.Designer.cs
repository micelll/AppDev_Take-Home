﻿namespace TH_Week4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_teamList = new System.Windows.Forms.Label();
            this.lb_country = new System.Windows.Forms.Label();
            this.lb_team = new System.Windows.Forms.Label();
            this.cb_country = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.listB_players = new System.Windows.Forms.ListBox();
            this.btn_remove = new System.Windows.Forms.Button();
            this.lb_addTeam = new System.Windows.Forms.Label();
            this.lb_teamName = new System.Windows.Forms.Label();
            this.lb_teamCountry = new System.Windows.Forms.Label();
            this.lb_teamCity = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.tb_country = new System.Windows.Forms.TextBox();
            this.tb_city = new System.Windows.Forms.TextBox();
            this.btn_addTeam = new System.Windows.Forms.Button();
            this.lb_playName = new System.Windows.Forms.Label();
            this.lb_playNum = new System.Windows.Forms.Label();
            this.lb_playPosition = new System.Windows.Forms.Label();
            this.tb_playName = new System.Windows.Forms.TextBox();
            this.tb_playNum = new System.Windows.Forms.TextBox();
            this.cb_playPosition = new System.Windows.Forms.ComboBox();
            this.lb_addPlayers = new System.Windows.Forms.Label();
            this.btn_addPlayer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_teamList
            // 
            this.lb_teamList.AutoSize = true;
            this.lb_teamList.Location = new System.Drawing.Point(63, 113);
            this.lb_teamList.Name = "lb_teamList";
            this.lb_teamList.Size = new System.Drawing.Size(233, 32);
            this.lb_teamList.TabIndex = 0;
            this.lb_teamList.Text = "Soccer Team List";
            // 
            // lb_country
            // 
            this.lb_country.AutoSize = true;
            this.lb_country.Location = new System.Drawing.Point(63, 185);
            this.lb_country.Name = "lb_country";
            this.lb_country.Size = new System.Drawing.Size(226, 32);
            this.lb_country.TabIndex = 1;
            this.lb_country.Text = "Choose Country:";
            // 
            // lb_team
            // 
            this.lb_team.AutoSize = true;
            this.lb_team.Location = new System.Drawing.Point(63, 262);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(199, 32);
            this.lb_team.TabIndex = 2;
            this.lb_team.Text = "Choose Team:";
            // 
            // cb_country
            // 
            this.cb_country.FormattingEnabled = true;
            this.cb_country.Items.AddRange(new object[] {
            "England",
            "Germany"});
            this.cb_country.Location = new System.Drawing.Point(326, 185);
            this.cb_country.Name = "cb_country";
            this.cb_country.Size = new System.Drawing.Size(258, 39);
            this.cb_country.TabIndex = 3;
            this.cb_country.SelectedIndexChanged += new System.EventHandler(this.cb_country_SelectedIndexChanged);
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(326, 259);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(258, 39);
            this.cb_team.TabIndex = 4;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // listB_players
            // 
            this.listB_players.FormattingEnabled = true;
            this.listB_players.ItemHeight = 31;
            this.listB_players.Location = new System.Drawing.Point(69, 355);
            this.listB_players.Name = "listB_players";
            this.listB_players.Size = new System.Drawing.Size(519, 283);
            this.listB_players.TabIndex = 5;
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(69, 683);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(157, 57);
            this.btn_remove.TabIndex = 6;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // lb_addTeam
            // 
            this.lb_addTeam.AutoSize = true;
            this.lb_addTeam.Location = new System.Drawing.Point(891, 113);
            this.lb_addTeam.Name = "lb_addTeam";
            this.lb_addTeam.Size = new System.Drawing.Size(183, 32);
            this.lb_addTeam.TabIndex = 7;
            this.lb_addTeam.Text = "Adding Team";
            // 
            // lb_teamName
            // 
            this.lb_teamName.AutoSize = true;
            this.lb_teamName.Location = new System.Drawing.Point(662, 185);
            this.lb_teamName.Name = "lb_teamName";
            this.lb_teamName.Size = new System.Drawing.Size(176, 32);
            this.lb_teamName.TabIndex = 8;
            this.lb_teamName.Text = "Team Name:";
            // 
            // lb_teamCountry
            // 
            this.lb_teamCountry.AutoSize = true;
            this.lb_teamCountry.Location = new System.Drawing.Point(662, 262);
            this.lb_teamCountry.Name = "lb_teamCountry";
            this.lb_teamCountry.Size = new System.Drawing.Size(200, 32);
            this.lb_teamCountry.TabIndex = 9;
            this.lb_teamCountry.Text = "Team Country:";
            // 
            // lb_teamCity
            // 
            this.lb_teamCity.AutoSize = true;
            this.lb_teamCity.Location = new System.Drawing.Point(662, 338);
            this.lb_teamCity.Name = "lb_teamCity";
            this.lb_teamCity.Size = new System.Drawing.Size(150, 32);
            this.lb_teamCity.TabIndex = 10;
            this.lb_teamCity.Text = "Team City:";
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(897, 185);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(226, 38);
            this.tb_name.TabIndex = 11;
            // 
            // tb_country
            // 
            this.tb_country.Location = new System.Drawing.Point(897, 259);
            this.tb_country.Name = "tb_country";
            this.tb_country.Size = new System.Drawing.Size(226, 38);
            this.tb_country.TabIndex = 12;
            // 
            // tb_city
            // 
            this.tb_city.Location = new System.Drawing.Point(897, 337);
            this.tb_city.Name = "tb_city";
            this.tb_city.Size = new System.Drawing.Size(226, 38);
            this.tb_city.TabIndex = 13;
            // 
            // btn_addTeam
            // 
            this.btn_addTeam.Location = new System.Drawing.Point(897, 416);
            this.btn_addTeam.Name = "btn_addTeam";
            this.btn_addTeam.Size = new System.Drawing.Size(157, 57);
            this.btn_addTeam.TabIndex = 14;
            this.btn_addTeam.Text = "Add";
            this.btn_addTeam.UseVisualStyleBackColor = true;
            this.btn_addTeam.Click += new System.EventHandler(this.btn_addTeam_Click);
            // 
            // lb_playName
            // 
            this.lb_playName.AutoSize = true;
            this.lb_playName.Location = new System.Drawing.Point(1207, 185);
            this.lb_playName.Name = "lb_playName";
            this.lb_playName.Size = new System.Drawing.Size(185, 32);
            this.lb_playName.TabIndex = 15;
            this.lb_playName.Text = "Player Name:";
            // 
            // lb_playNum
            // 
            this.lb_playNum.AutoSize = true;
            this.lb_playNum.Location = new System.Drawing.Point(1207, 259);
            this.lb_playNum.Name = "lb_playNum";
            this.lb_playNum.Size = new System.Drawing.Size(210, 32);
            this.lb_playNum.TabIndex = 16;
            this.lb_playNum.Text = "Player Number:";
            // 
            // lb_playPosition
            // 
            this.lb_playPosition.AutoSize = true;
            this.lb_playPosition.Location = new System.Drawing.Point(1207, 336);
            this.lb_playPosition.Name = "lb_playPosition";
            this.lb_playPosition.Size = new System.Drawing.Size(213, 32);
            this.lb_playPosition.TabIndex = 17;
            this.lb_playPosition.Text = "Player Position:";
            // 
            // tb_playName
            // 
            this.tb_playName.Location = new System.Drawing.Point(1456, 181);
            this.tb_playName.Name = "tb_playName";
            this.tb_playName.Size = new System.Drawing.Size(226, 38);
            this.tb_playName.TabIndex = 18;
            // 
            // tb_playNum
            // 
            this.tb_playNum.Location = new System.Drawing.Point(1456, 257);
            this.tb_playNum.Name = "tb_playNum";
            this.tb_playNum.Size = new System.Drawing.Size(226, 38);
            this.tb_playNum.TabIndex = 19;
            // 
            // cb_playPosition
            // 
            this.cb_playPosition.FormattingEnabled = true;
            this.cb_playPosition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cb_playPosition.Location = new System.Drawing.Point(1456, 338);
            this.cb_playPosition.Name = "cb_playPosition";
            this.cb_playPosition.Size = new System.Drawing.Size(226, 39);
            this.cb_playPosition.TabIndex = 20;
            // 
            // lb_addPlayers
            // 
            this.lb_addPlayers.AutoSize = true;
            this.lb_addPlayers.Location = new System.Drawing.Point(1450, 113);
            this.lb_addPlayers.Name = "lb_addPlayers";
            this.lb_addPlayers.Size = new System.Drawing.Size(206, 32);
            this.lb_addPlayers.TabIndex = 21;
            this.lb_addPlayers.Text = "Adding Players";
            // 
            // btn_addPlayer
            // 
            this.btn_addPlayer.Location = new System.Drawing.Point(1456, 416);
            this.btn_addPlayer.Name = "btn_addPlayer";
            this.btn_addPlayer.Size = new System.Drawing.Size(157, 57);
            this.btn_addPlayer.TabIndex = 22;
            this.btn_addPlayer.Text = "Add";
            this.btn_addPlayer.UseVisualStyleBackColor = true;
            this.btn_addPlayer.Click += new System.EventHandler(this.btn_addPlayer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1747, 1164);
            this.Controls.Add(this.btn_addPlayer);
            this.Controls.Add(this.lb_addPlayers);
            this.Controls.Add(this.cb_playPosition);
            this.Controls.Add(this.tb_playNum);
            this.Controls.Add(this.tb_playName);
            this.Controls.Add(this.lb_playPosition);
            this.Controls.Add(this.lb_playNum);
            this.Controls.Add(this.lb_playName);
            this.Controls.Add(this.btn_addTeam);
            this.Controls.Add(this.tb_city);
            this.Controls.Add(this.tb_country);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.lb_teamCity);
            this.Controls.Add(this.lb_teamCountry);
            this.Controls.Add(this.lb_teamName);
            this.Controls.Add(this.lb_addTeam);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.listB_players);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.cb_country);
            this.Controls.Add(this.lb_team);
            this.Controls.Add(this.lb_country);
            this.Controls.Add(this.lb_teamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_teamList;
        private System.Windows.Forms.Label lb_country;
        private System.Windows.Forms.Label lb_team;
        private System.Windows.Forms.ComboBox cb_country;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ListBox listB_players;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Label lb_addTeam;
        private System.Windows.Forms.Label lb_teamName;
        private System.Windows.Forms.Label lb_teamCountry;
        private System.Windows.Forms.Label lb_teamCity;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.TextBox tb_country;
        private System.Windows.Forms.TextBox tb_city;
        private System.Windows.Forms.Button btn_addTeam;
        private System.Windows.Forms.Label lb_playName;
        private System.Windows.Forms.Label lb_playNum;
        private System.Windows.Forms.Label lb_playPosition;
        private System.Windows.Forms.TextBox tb_playName;
        private System.Windows.Forms.TextBox tb_playNum;
        private System.Windows.Forms.ComboBox cb_playPosition;
        private System.Windows.Forms.Label lb_addPlayers;
        private System.Windows.Forms.Button btn_addPlayer;
    }
}


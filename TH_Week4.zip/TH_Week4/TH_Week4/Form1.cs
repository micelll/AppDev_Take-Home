﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_Week4
{
    public partial class Form1 : Form
    {
        DataTable dtTeam = new DataTable();
        DataTable dtPlayers = new DataTable();

        public string all;

        public string teamTerpilih;
        public Form1()
        {
            InitializeComponent();
        }

        private void cb_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            string countryTerpilih = cb_country.SelectedItem.ToString();
            cb_team.Items.Clear();

            foreach (DataRow row in dtTeam.Rows)
            {
                if (row["Country"].ToString() == countryTerpilih)
                {
                    string team = row["Team"].ToString();
                    cb_team.Items.Add(team);
                }
            }
            cb_team.Text = "";
        }

        private void btn_addTeam_Click(object sender, EventArgs e)
        {
            if (tb_country.Text == "" || tb_name.Text == "" || tb_city.Text == "")
            {
                MessageBox.Show("All fields needs to be filled", "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            else
            {
                bool cekTeam = false;
                foreach (DataRow row in dtTeam.Rows)
                {
                    if (row["Team"].ToString() == tb_name.Text)
                    {
                        cekTeam = true;
                        break;
                    }
                }
                if (!cekTeam)
                {
                    dtTeam.Rows.Add(tb_country.Text, tb_name.Text);
                    foreach (DataRow row in dtTeam.Rows)
                    {
                        string country = row["Country"].ToString();
                        if (!cb_country.Items.Contains(country))
                        {
                            cb_country.Items.Add(country);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("The team name already exist", "Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                }
            }
            tb_country.Clear();
            tb_name.Clear();
            tb_city.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtTeam.Columns.Add("Country");
            dtTeam.Columns.Add("Team");

            dtTeam.Rows.Add("England", "Manchester United");
            dtTeam.Rows.Add("England", "Chelsea");
            dtTeam.Rows.Add("Germany", "Bayem Munich");

            foreach (DataRow row in dtTeam.Rows)
            {
                string country = row["Country"].ToString();
                if (!cb_country.Items.Contains(country))
                {
                    cb_country.Items.Add(country);
                }
            }

            dtPlayers.Columns.Add("Team");
            dtPlayers.Columns.Add("Number");
            dtPlayers.Columns.Add("Name");
            dtPlayers.Columns.Add("Position");

            dtPlayers.Rows.Add("Manchester United","01", "David De Gea", "GK");
            dtPlayers.Rows.Add("Manchester United", "02", "Victor Lindelof", "DF");
            dtPlayers.Rows.Add("Manchester United", "04", "Phil Jones", "DF");
            dtPlayers.Rows.Add("Manchester United", "05", "Harry Maguire", "DF");
            dtPlayers.Rows.Add("Manchester United", "06", "Lisandro Martines", "DF");
            dtPlayers.Rows.Add("Manchester United", "08", "Bruno Femandez", "MF");
            dtPlayers.Rows.Add("Manchester United", "09", "Anthony Martial", "FW");
            dtPlayers.Rows.Add("Manchester United", "10", "Marcus Rashford", "FW");
            dtPlayers.Rows.Add("Manchester United", "12", "Tyrell Malacia", "DF");
            dtPlayers.Rows.Add("Manchester United", "14", "Christian Eriksen", "MF");
            dtPlayers.Rows.Add("Manchester United", "18", "Casemiro", "MF");

            dtPlayers.Rows.Add("Chelsea", "01", "Kepa Arrizabalaga", "GK");
            dtPlayers.Rows.Add("Chelsea", "04", "Benoit Badiashile", "DF");
            dtPlayers.Rows.Add("Chelsea", "05", "Enzo Femandez", "MF");
            dtPlayers.Rows.Add("Chelsea", "06", "Thiago Silva", "DF");
            dtPlayers.Rows.Add("Chelsea", "07", "N'Golo Kante", "MF");
            dtPlayers.Rows.Add("Chelsea", "08", "Mateo Kovacic", "MF");
            dtPlayers.Rows.Add("Chelsea", "09", "Pierre-Emerick Aubameyang", "FW");
            dtPlayers.Rows.Add("Chelsea", "10", "Christian Pulisic", "MF");
            dtPlayers.Rows.Add("Chelsea", "11", "Joao Felix", "FW");
            dtPlayers.Rows.Add("Chelsea", "12", "Ruben Loftus-Cheek", "MF");
            dtPlayers.Rows.Add("Chelsea", "17", "Raheem Sterling", "MF");

            dtPlayers.Rows.Add("Bayem Munich", "01", "Manuel Neuer", "GK");
            dtPlayers.Rows.Add("Bayem Munich", "02", "Dayot Upamecano", "DF");
            dtPlayers.Rows.Add("Bayem Munich", "04", "Matthijs de Ligt", "DF");
            dtPlayers.Rows.Add("Bayem Munich", "05", "Benjamin Pavard", "DF");
            dtPlayers.Rows.Add("Bayem Munich", "06", "Joshua Kimmich", "MF");
            dtPlayers.Rows.Add("Bayem Munich", "07", "Serge Gnabry", "FW");
            dtPlayers.Rows.Add("Bayem Munich", "08", "Leon Goretzka", "MF");
            dtPlayers.Rows.Add("Bayem Munich", "10", "Leroy Sane", "FW");
            dtPlayers.Rows.Add("Bayem Munich", "14", "Paul Wanner", "MF");
            dtPlayers.Rows.Add("Bayem Munich", "21", "Lucas Hemandez", "DF");
            dtPlayers.Rows.Add("Bayem Munich", "25", "Thommas Muller", "FW");
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            teamTerpilih = cb_team.SelectedItem.ToString();
            listB_players.Items.Clear();
            
            foreach (DataRow row in dtPlayers.Rows)
            {
                if (row["Team"].ToString() == teamTerpilih)
                {
                    string number = row["Number"].ToString();
                    string name = row["Name"].ToString();
                    string position = row["Position"].ToString();
                    string all = "(" + number +") " + name + ", " + position;
                    listB_players.Items.Add(all);
                }
            }
        }

        private void btn_addPlayer_Click(object sender, EventArgs e)
        {

            if (tb_playName.Text == "" || tb_playNum.Text == "" || cb_playPosition.SelectedItem == null)
            {
                MessageBox.Show("All fields needs to be filled", "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            else
            {
                bool cek = false;
                foreach (DataRow row in dtPlayers.Rows)
                {
                    if (row["Team"].ToString() == cb_team.SelectedItem)
                    {
                        if (row["Number"].ToString() == tb_playNum.Text)
                        {
                            cek = true;
                            break;
                        }
                    }
                }
                if (!cek)
                {
                    string positionTerpilih = cb_playPosition.SelectedItem.ToString();
                    dtPlayers.Rows.Add(teamTerpilih, tb_playNum.Text, tb_playName.Text, positionTerpilih);

                    foreach (DataRow row in dtPlayers.Rows)
                    {
                        if (row["Team"].ToString() == teamTerpilih)
                        {
                            string number = row["Number"].ToString();
                            string name = row["Name"].ToString();
                            string position = row["Position"].ToString();
                            all = "(" + number + ") " + name + ", " + position;
                        }
                    }
                    listB_players.Items.Add(all);
                }
                else
                {
                    MessageBox.Show("Player with Same Number is found", "Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
                tb_playName.Clear();
                tb_playNum.Clear();
            }
        }
        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (listB_players.Items.Count < 12)
            {
                MessageBox.Show("Unable to Remove Players if Players less than equal to 11", "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            else
            {
                string[] split = listB_players.SelectedItem.ToString().Split(',');
                string num = split[0].Substring(1, 2);
                string team = cb_team.SelectedItem.ToString();

                foreach (DataRow row in dtPlayers.Rows)
                {
                    if (row["Team"].ToString() == team)
                    {
                        if (row["Number"].ToString() == num)
                        {
                            dtPlayers.Rows.Remove(row);
                            break;
                        }
                    }
                }
                listB_players.Items.Remove(listB_players.SelectedItem);
            }
        }
    }
}

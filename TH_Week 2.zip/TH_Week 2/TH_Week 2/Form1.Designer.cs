﻿namespace TH_Week_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Word1 = new System.Windows.Forms.Label();
            this.tb_Kata1 = new System.Windows.Forms.TextBox();
            this.lb_Word2 = new System.Windows.Forms.Label();
            this.lb_Word3 = new System.Windows.Forms.Label();
            this.lb_Word4 = new System.Windows.Forms.Label();
            this.lb_Word5 = new System.Windows.Forms.Label();
            this.tb_Kata2 = new System.Windows.Forms.TextBox();
            this.tb_Kata3 = new System.Windows.Forms.TextBox();
            this.tb_Kata4 = new System.Windows.Forms.TextBox();
            this.tb_Kata5 = new System.Windows.Forms.TextBox();
            this.btn_Play = new System.Windows.Forms.Button();
            this.panel_Kata = new System.Windows.Forms.Panel();
            this.btn_A = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_Q = new System.Windows.Forms.Button();
            this.btn_W = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.btn_I = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_Z = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_M = new System.Windows.Forms.Button();
            this.lb_huruf1 = new System.Windows.Forms.Label();
            this.lb_huruf2 = new System.Windows.Forms.Label();
            this.lb_huruf4 = new System.Windows.Forms.Label();
            this.lb_huruf3 = new System.Windows.Forms.Label();
            this.lb_huruf5 = new System.Windows.Forms.Label();
            this.panel_keys = new System.Windows.Forms.Panel();
            this.panel_Kata.SuspendLayout();
            this.panel_keys.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_Word1
            // 
            this.lb_Word1.AutoSize = true;
            this.lb_Word1.Location = new System.Drawing.Point(49, 35);
            this.lb_Word1.Name = "lb_Word1";
            this.lb_Word1.Size = new System.Drawing.Size(104, 32);
            this.lb_Word1.TabIndex = 0;
            this.lb_Word1.Text = "Word 1";
            // 
            // tb_Kata1
            // 
            this.tb_Kata1.Location = new System.Drawing.Point(190, 35);
            this.tb_Kata1.Name = "tb_Kata1";
            this.tb_Kata1.Size = new System.Drawing.Size(190, 38);
            this.tb_Kata1.TabIndex = 1;
            // 
            // lb_Word2
            // 
            this.lb_Word2.AutoSize = true;
            this.lb_Word2.Location = new System.Drawing.Point(51, 104);
            this.lb_Word2.Name = "lb_Word2";
            this.lb_Word2.Size = new System.Drawing.Size(104, 32);
            this.lb_Word2.TabIndex = 2;
            this.lb_Word2.Text = "Word 2";
            // 
            // lb_Word3
            // 
            this.lb_Word3.AutoSize = true;
            this.lb_Word3.Location = new System.Drawing.Point(51, 167);
            this.lb_Word3.Name = "lb_Word3";
            this.lb_Word3.Size = new System.Drawing.Size(104, 32);
            this.lb_Word3.TabIndex = 3;
            this.lb_Word3.Text = "Word 3";
            // 
            // lb_Word4
            // 
            this.lb_Word4.AutoSize = true;
            this.lb_Word4.Location = new System.Drawing.Point(49, 232);
            this.lb_Word4.Name = "lb_Word4";
            this.lb_Word4.Size = new System.Drawing.Size(104, 32);
            this.lb_Word4.TabIndex = 4;
            this.lb_Word4.Text = "Word 4";
            // 
            // lb_Word5
            // 
            this.lb_Word5.AutoSize = true;
            this.lb_Word5.Location = new System.Drawing.Point(49, 296);
            this.lb_Word5.Name = "lb_Word5";
            this.lb_Word5.Size = new System.Drawing.Size(104, 32);
            this.lb_Word5.TabIndex = 5;
            this.lb_Word5.Text = "Word 5";
            // 
            // tb_Kata2
            // 
            this.tb_Kata2.Location = new System.Drawing.Point(190, 104);
            this.tb_Kata2.Name = "tb_Kata2";
            this.tb_Kata2.Size = new System.Drawing.Size(190, 38);
            this.tb_Kata2.TabIndex = 6;
            // 
            // tb_Kata3
            // 
            this.tb_Kata3.Location = new System.Drawing.Point(190, 167);
            this.tb_Kata3.Name = "tb_Kata3";
            this.tb_Kata3.Size = new System.Drawing.Size(190, 38);
            this.tb_Kata3.TabIndex = 7;
            // 
            // tb_Kata4
            // 
            this.tb_Kata4.Location = new System.Drawing.Point(190, 232);
            this.tb_Kata4.Name = "tb_Kata4";
            this.tb_Kata4.Size = new System.Drawing.Size(190, 38);
            this.tb_Kata4.TabIndex = 8;
            // 
            // tb_Kata5
            // 
            this.tb_Kata5.Location = new System.Drawing.Point(190, 296);
            this.tb_Kata5.Name = "tb_Kata5";
            this.tb_Kata5.Size = new System.Drawing.Size(190, 38);
            this.tb_Kata5.TabIndex = 9;
            // 
            // btn_Play
            // 
            this.btn_Play.Location = new System.Drawing.Point(87, 412);
            this.btn_Play.Name = "btn_Play";
            this.btn_Play.Size = new System.Drawing.Size(248, 77);
            this.btn_Play.TabIndex = 11;
            this.btn_Play.Text = "Play!";
            this.btn_Play.UseVisualStyleBackColor = true;
            this.btn_Play.Click += new System.EventHandler(this.btn_Play_Click);
            // 
            // panel_Kata
            // 
            this.panel_Kata.Controls.Add(this.btn_Play);
            this.panel_Kata.Controls.Add(this.lb_Word1);
            this.panel_Kata.Controls.Add(this.tb_Kata5);
            this.panel_Kata.Controls.Add(this.tb_Kata1);
            this.panel_Kata.Controls.Add(this.tb_Kata4);
            this.panel_Kata.Controls.Add(this.lb_Word2);
            this.panel_Kata.Controls.Add(this.tb_Kata3);
            this.panel_Kata.Controls.Add(this.lb_Word3);
            this.panel_Kata.Controls.Add(this.tb_Kata2);
            this.panel_Kata.Controls.Add(this.lb_Word4);
            this.panel_Kata.Controls.Add(this.lb_Word5);
            this.panel_Kata.Location = new System.Drawing.Point(12, 12);
            this.panel_Kata.Name = "panel_Kata";
            this.panel_Kata.Size = new System.Drawing.Size(437, 577);
            this.panel_Kata.TabIndex = 12;
            // 
            // btn_A
            // 
            this.btn_A.Location = new System.Drawing.Point(102, 427);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(119, 111);
            this.btn_A.TabIndex = 13;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = true;
            this.btn_A.Click += new System.EventHandler(this.btn_A_Click);
            // 
            // btn_B
            // 
            this.btn_B.Location = new System.Drawing.Point(908, 575);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(119, 111);
            this.btn_B.TabIndex = 14;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = true;
            this.btn_B.Click += new System.EventHandler(this.btn_B_Click);
            // 
            // btn_C
            // 
            this.btn_C.Location = new System.Drawing.Point(585, 575);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(119, 111);
            this.btn_C.TabIndex = 15;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.btn_C_Click);
            // 
            // btn_D
            // 
            this.btn_D.Location = new System.Drawing.Point(424, 427);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(119, 111);
            this.btn_D.TabIndex = 16;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = true;
            this.btn_D.Click += new System.EventHandler(this.btn_D_Click);
            // 
            // btn_E
            // 
            this.btn_E.Location = new System.Drawing.Point(343, 280);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(119, 111);
            this.btn_E.TabIndex = 17;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = true;
            this.btn_E.Click += new System.EventHandler(this.btn_E_Click);
            // 
            // btn_F
            // 
            this.btn_F.Location = new System.Drawing.Point(589, 427);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(119, 111);
            this.btn_F.TabIndex = 18;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = true;
            this.btn_F.Click += new System.EventHandler(this.btn_F_Click);
            // 
            // btn_G
            // 
            this.btn_G.Location = new System.Drawing.Point(748, 427);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(119, 111);
            this.btn_G.TabIndex = 19;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = true;
            this.btn_G.Click += new System.EventHandler(this.btn_G_Click);
            // 
            // btn_Q
            // 
            this.btn_Q.Location = new System.Drawing.Point(24, 280);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(119, 111);
            this.btn_Q.TabIndex = 20;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = true;
            this.btn_Q.Click += new System.EventHandler(this.btn_Q_Click);
            // 
            // btn_W
            // 
            this.btn_W.Location = new System.Drawing.Point(184, 280);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(119, 111);
            this.btn_W.TabIndex = 21;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = true;
            this.btn_W.Click += new System.EventHandler(this.btn_W_Click);
            // 
            // btn_R
            // 
            this.btn_R.Location = new System.Drawing.Point(505, 280);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(119, 111);
            this.btn_R.TabIndex = 22;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = true;
            this.btn_R.Click += new System.EventHandler(this.btn_R_Click);
            // 
            // btn_T
            // 
            this.btn_T.Location = new System.Drawing.Point(671, 280);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(119, 111);
            this.btn_T.TabIndex = 23;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = true;
            this.btn_T.Click += new System.EventHandler(this.btn_T_Click);
            // 
            // btn_Y
            // 
            this.btn_Y.Location = new System.Drawing.Point(827, 279);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(119, 111);
            this.btn_Y.TabIndex = 24;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = true;
            this.btn_Y.Click += new System.EventHandler(this.btn_Y_Click);
            // 
            // btn_U
            // 
            this.btn_U.Location = new System.Drawing.Point(985, 279);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(119, 111);
            this.btn_U.TabIndex = 25;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = true;
            this.btn_U.Click += new System.EventHandler(this.btn_U_Click);
            // 
            // btn_I
            // 
            this.btn_I.Location = new System.Drawing.Point(1146, 279);
            this.btn_I.Name = "btn_I";
            this.btn_I.Size = new System.Drawing.Size(119, 111);
            this.btn_I.TabIndex = 26;
            this.btn_I.Text = "I";
            this.btn_I.UseVisualStyleBackColor = true;
            this.btn_I.Click += new System.EventHandler(this.btn_I_Click);
            // 
            // btn_O
            // 
            this.btn_O.Location = new System.Drawing.Point(1308, 279);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(119, 111);
            this.btn_O.TabIndex = 27;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = true;
            this.btn_O.Click += new System.EventHandler(this.btn_O_Click);
            // 
            // btn_P
            // 
            this.btn_P.Location = new System.Drawing.Point(1473, 279);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(119, 111);
            this.btn_P.TabIndex = 28;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = true;
            this.btn_P.Click += new System.EventHandler(this.btn_P_Click);
            // 
            // btn_S
            // 
            this.btn_S.Location = new System.Drawing.Point(262, 427);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(119, 111);
            this.btn_S.TabIndex = 29;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = true;
            this.btn_S.Click += new System.EventHandler(this.btn_S_Click);
            // 
            // btn_H
            // 
            this.btn_H.Location = new System.Drawing.Point(906, 427);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(119, 111);
            this.btn_H.TabIndex = 30;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = true;
            this.btn_H.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_J
            // 
            this.btn_J.Location = new System.Drawing.Point(1066, 427);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(119, 111);
            this.btn_J.TabIndex = 31;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = true;
            this.btn_J.Click += new System.EventHandler(this.btn_J_Click);
            // 
            // btn_K
            // 
            this.btn_K.Location = new System.Drawing.Point(1227, 427);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(119, 111);
            this.btn_K.TabIndex = 32;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = true;
            this.btn_K.Click += new System.EventHandler(this.btn_K_Click);
            // 
            // btn_L
            // 
            this.btn_L.Location = new System.Drawing.Point(1388, 427);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(119, 111);
            this.btn_L.TabIndex = 33;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = true;
            this.btn_L.Click += new System.EventHandler(this.btn_L_Click);
            // 
            // btn_Z
            // 
            this.btn_Z.Location = new System.Drawing.Point(264, 575);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(119, 111);
            this.btn_Z.TabIndex = 34;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = true;
            this.btn_Z.Click += new System.EventHandler(this.btn_Z_Click);
            // 
            // btn_X
            // 
            this.btn_X.Location = new System.Drawing.Point(423, 575);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(119, 111);
            this.btn_X.TabIndex = 35;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = true;
            this.btn_X.Click += new System.EventHandler(this.btn_X_Click);
            // 
            // btn_V
            // 
            this.btn_V.Location = new System.Drawing.Point(751, 575);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(119, 111);
            this.btn_V.TabIndex = 36;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = true;
            this.btn_V.Click += new System.EventHandler(this.btn_V_Click);
            // 
            // btn_N
            // 
            this.btn_N.Location = new System.Drawing.Point(1066, 575);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(119, 111);
            this.btn_N.TabIndex = 37;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = true;
            this.btn_N.Click += new System.EventHandler(this.btn_N_Click);
            // 
            // btn_M
            // 
            this.btn_M.Location = new System.Drawing.Point(1226, 575);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(119, 111);
            this.btn_M.TabIndex = 38;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = true;
            this.btn_M.Click += new System.EventHandler(this.btn_M_Click);
            // 
            // lb_huruf1
            // 
            this.lb_huruf1.AutoSize = true;
            this.lb_huruf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_huruf1.Location = new System.Drawing.Point(440, 65);
            this.lb_huruf1.Name = "lb_huruf1";
            this.lb_huruf1.Size = new System.Drawing.Size(124, 135);
            this.lb_huruf1.TabIndex = 39;
            this.lb_huruf1.Text = "_";
            // 
            // lb_huruf2
            // 
            this.lb_huruf2.AutoSize = true;
            this.lb_huruf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_huruf2.Location = new System.Drawing.Point(588, 65);
            this.lb_huruf2.Name = "lb_huruf2";
            this.lb_huruf2.Size = new System.Drawing.Size(124, 135);
            this.lb_huruf2.TabIndex = 40;
            this.lb_huruf2.Text = "_";
            // 
            // lb_huruf4
            // 
            this.lb_huruf4.AutoSize = true;
            this.lb_huruf4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_huruf4.Location = new System.Drawing.Point(876, 64);
            this.lb_huruf4.Name = "lb_huruf4";
            this.lb_huruf4.Size = new System.Drawing.Size(124, 135);
            this.lb_huruf4.TabIndex = 41;
            this.lb_huruf4.Text = "_";
            // 
            // lb_huruf3
            // 
            this.lb_huruf3.AutoSize = true;
            this.lb_huruf3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_huruf3.Location = new System.Drawing.Point(733, 64);
            this.lb_huruf3.Name = "lb_huruf3";
            this.lb_huruf3.Size = new System.Drawing.Size(124, 135);
            this.lb_huruf3.TabIndex = 42;
            this.lb_huruf3.Text = "_";
            // 
            // lb_huruf5
            // 
            this.lb_huruf5.AutoSize = true;
            this.lb_huruf5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_huruf5.Location = new System.Drawing.Point(1019, 64);
            this.lb_huruf5.Name = "lb_huruf5";
            this.lb_huruf5.Size = new System.Drawing.Size(124, 135);
            this.lb_huruf5.TabIndex = 43;
            this.lb_huruf5.Text = "_";
            // 
            // panel_keys
            // 
            this.panel_keys.Controls.Add(this.lb_huruf5);
            this.panel_keys.Controls.Add(this.lb_huruf3);
            this.panel_keys.Controls.Add(this.btn_A);
            this.panel_keys.Controls.Add(this.lb_huruf4);
            this.panel_keys.Controls.Add(this.btn_B);
            this.panel_keys.Controls.Add(this.lb_huruf2);
            this.panel_keys.Controls.Add(this.btn_C);
            this.panel_keys.Controls.Add(this.lb_huruf1);
            this.panel_keys.Controls.Add(this.btn_D);
            this.panel_keys.Controls.Add(this.btn_M);
            this.panel_keys.Controls.Add(this.btn_E);
            this.panel_keys.Controls.Add(this.btn_N);
            this.panel_keys.Controls.Add(this.btn_F);
            this.panel_keys.Controls.Add(this.btn_V);
            this.panel_keys.Controls.Add(this.btn_G);
            this.panel_keys.Controls.Add(this.btn_X);
            this.panel_keys.Controls.Add(this.btn_Q);
            this.panel_keys.Controls.Add(this.btn_Z);
            this.panel_keys.Controls.Add(this.btn_W);
            this.panel_keys.Controls.Add(this.btn_L);
            this.panel_keys.Controls.Add(this.btn_R);
            this.panel_keys.Controls.Add(this.btn_K);
            this.panel_keys.Controls.Add(this.btn_T);
            this.panel_keys.Controls.Add(this.btn_J);
            this.panel_keys.Controls.Add(this.btn_Y);
            this.panel_keys.Controls.Add(this.btn_H);
            this.panel_keys.Controls.Add(this.btn_U);
            this.panel_keys.Controls.Add(this.btn_S);
            this.panel_keys.Controls.Add(this.btn_I);
            this.panel_keys.Controls.Add(this.btn_P);
            this.panel_keys.Controls.Add(this.btn_O);
            this.panel_keys.Location = new System.Drawing.Point(202, 553);
            this.panel_keys.Name = "panel_keys";
            this.panel_keys.Size = new System.Drawing.Size(1634, 990);
            this.panel_keys.TabIndex = 12;
            this.panel_keys.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_keys_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2025, 1733);
            this.Controls.Add(this.panel_keys);
            this.Controls.Add(this.panel_Kata);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_Kata.ResumeLayout(false);
            this.panel_Kata.PerformLayout();
            this.panel_keys.ResumeLayout(false);
            this.panel_keys.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb_Word1;
        private System.Windows.Forms.TextBox tb_Kata1;
        private System.Windows.Forms.Label lb_Word2;
        private System.Windows.Forms.Label lb_Word3;
        private System.Windows.Forms.Label lb_Word4;
        private System.Windows.Forms.Label lb_Word5;
        private System.Windows.Forms.TextBox tb_Kata2;
        private System.Windows.Forms.TextBox tb_Kata3;
        private System.Windows.Forms.TextBox tb_Kata4;
        private System.Windows.Forms.TextBox tb_Kata5;
        private System.Windows.Forms.Button btn_Play;
        private System.Windows.Forms.Panel panel_Kata;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Button btn_W;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Button btn_I;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Label lb_huruf1;
        private System.Windows.Forms.Label lb_huruf2;
        private System.Windows.Forms.Label lb_huruf4;
        private System.Windows.Forms.Label lb_huruf3;
        private System.Windows.Forms.Label lb_huruf5;
        private System.Windows.Forms.Panel panel_keys;
    }
}


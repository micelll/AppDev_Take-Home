﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_Week_2
{
    public partial class Form1 : Form
    {
        List<string> hurufKata = new List<string>() { "_", "_", "_", "_", "_" };
        List<string> isi = new List<string>();

        public string kataDipilih;
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Play_Click(object sender, EventArgs e)
        {

            if (tb_Kata1.Text == tb_Kata2.Text || tb_Kata1.Text == tb_Kata3.Text || tb_Kata1.Text == tb_Kata4.Text || tb_Kata1.Text == tb_Kata5.Text || tb_Kata2.Text == tb_Kata3.Text || tb_Kata2.Text == tb_Kata4.Text || tb_Kata2.Text == tb_Kata5.Text || tb_Kata3.Text == tb_Kata4.Text || tb_Kata3.Text == tb_Kata5.Text || tb_Kata4.Text == tb_Kata5.Text)
            {
                MessageBox.Show("There's still an error!");
            }
            else if (tb_Kata1.Text.Length != 5 || tb_Kata2.Text.Length != 5 || tb_Kata3.Text.Length != 5 || tb_Kata4.Text.Length != 5 || tb_Kata5.Text.Length != 5)
            {
                MessageBox.Show("There's still an error!");
            }
            else if (tb_Kata1.Text == "" || tb_Kata2.Text == "" || tb_Kata3.Text == "" || tb_Kata4.Text == "" || tb_Kata5.Text == "")
            {
                MessageBox.Show("There's still an error!");
            }
            else
            {
                MessageBox.Show("Let's Play!");

                panel_Kata.Visible = false;
                panel_keys.Visible = true;

                isi.Add(tb_Kata1.Text.ToUpper());
                isi.Add(tb_Kata2.Text.ToUpper());
                isi.Add(tb_Kata3.Text.ToUpper());
                isi.Add(tb_Kata4.Text.ToUpper());
                isi.Add(tb_Kata5.Text.ToUpper());

                Random rnd = new Random();
                int indexKata = rnd.Next(isi.Count);

                kataDipilih = isi[indexKata].ToUpper();
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            panel_keys.Visible = false;
        }

        private void panel_keys_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void ngecek(char letter)
        {
            char[] huruf = new char[kataDipilih.Length];

            for (int i = 0; i < kataDipilih.Length; i++)
            {
                huruf[i] = kataDipilih[i];
            }

            if (kataDipilih.Contains(letter))
            {
                for (int i = 0; i < kataDipilih.Length; i++)
                {
                    if (huruf[i] == letter)
                    {
                        hurufKata[i] = letter.ToString();
                    }
                }
            }

            lb_huruf1.Text = hurufKata[0];
            lb_huruf2.Text = hurufKata[1];
            lb_huruf3.Text = hurufKata[2];
            lb_huruf4.Text = hurufKata[3];
            lb_huruf5.Text = hurufKata[4];

            if (lb_huruf1.Text != "_" && lb_huruf2.Text != "_" && lb_huruf3.Text != "_" && lb_huruf4.Text != "_" && lb_huruf5.Text != "_")
            {
                MessageBox.Show("You Won!");
                panel_keys.Refresh();
            }
        }
        private void btn_Q_Click(object sender, EventArgs e)
        {
            char letter = 'Q';
            ngecek(letter);
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            char letter = 'W';
            ngecek(letter);
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            char letter = 'A';
            ngecek(letter);
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            char letter = 'E';
            ngecek(letter);
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            char letter = 'R';
            ngecek(letter);
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            char letter = 'T';
            ngecek(letter);
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            char letter = 'Y';
            ngecek(letter);
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            char letter = 'U';
            ngecek(letter);
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            char letter = 'I';
            ngecek(letter);
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            char letter = 'O';
            ngecek(letter);
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            char letter = 'P';
            ngecek(letter);
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            char letter = 'S';
            ngecek(letter);
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            char letter = 'D';
            ngecek(letter);
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            char letter = 'F';
            ngecek(letter);
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            char letter = 'G';
            ngecek(letter);
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            char letter = 'H';
            ngecek(letter);
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            char letter = 'J';
            ngecek(letter);
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            char letter = 'K';
            ngecek(letter);
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            char letter = 'L';
            ngecek(letter);
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            char letter = 'Z';
            ngecek(letter);
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            char letter = 'X';
            ngecek(letter);
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            char letter = 'C';
            ngecek(letter);
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            char letter = 'V';
            ngecek(letter);
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            char letter = 'B';
            ngecek(letter);
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            char letter = 'N';
            ngecek(letter);
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            char letter = 'M';
            ngecek(letter);
        }
    }
}

﻿namespace TH_Week_8
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_cart = new System.Windows.Forms.DataGridView();
            this.lb_subtot = new System.Windows.Forms.Label();
            this.lb_total = new System.Windows.Forms.Label();
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.pb_tshirt1 = new System.Windows.Forms.PictureBox();
            this.pb_tshirt2 = new System.Windows.Forms.PictureBox();
            this.pb_tshirt3 = new System.Windows.Forms.PictureBox();
            this.lb_tshirt1 = new System.Windows.Forms.Label();
            this.lb_hargaT1 = new System.Windows.Forms.Label();
            this.btn_addT1 = new System.Windows.Forms.Button();
            this.lb_tshirt2 = new System.Windows.Forms.Label();
            this.lb_hargaT2 = new System.Windows.Forms.Label();
            this.btn_addT2 = new System.Windows.Forms.Button();
            this.lb_tshirt3 = new System.Windows.Forms.Label();
            this.lb_hargaT3 = new System.Windows.Forms.Label();
            this.btn_addT3 = new System.Windows.Forms.Button();
            this.panel_tshirt = new System.Windows.Forms.Panel();
            this.pb_shirt1 = new System.Windows.Forms.PictureBox();
            this.pb_shirt2 = new System.Windows.Forms.PictureBox();
            this.pb_shirt3 = new System.Windows.Forms.PictureBox();
            this.lb_shirt1 = new System.Windows.Forms.Label();
            this.lb_hargaS1 = new System.Windows.Forms.Label();
            this.btn_addS1 = new System.Windows.Forms.Button();
            this.lb_shirt2 = new System.Windows.Forms.Label();
            this.lb_hargaS2 = new System.Windows.Forms.Label();
            this.btn_addS2 = new System.Windows.Forms.Button();
            this.lb_shirt3 = new System.Windows.Forms.Label();
            this.lb_hargaS3 = new System.Windows.Forms.Label();
            this.btn_addS3 = new System.Windows.Forms.Button();
            this.panel_shirt = new System.Windows.Forms.Panel();
            this.btn_addP3 = new System.Windows.Forms.Button();
            this.lb_hargaP3 = new System.Windows.Forms.Label();
            this.lb_pants3 = new System.Windows.Forms.Label();
            this.btn_addP2 = new System.Windows.Forms.Button();
            this.lb_hargaP2 = new System.Windows.Forms.Label();
            this.lb_pants2 = new System.Windows.Forms.Label();
            this.btn_addP1 = new System.Windows.Forms.Button();
            this.lb_hargaP1 = new System.Windows.Forms.Label();
            this.lb_pants1 = new System.Windows.Forms.Label();
            this.pb_pants3 = new System.Windows.Forms.PictureBox();
            this.pb_pants2 = new System.Windows.Forms.PictureBox();
            this.pb_pants1 = new System.Windows.Forms.PictureBox();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.btn_addLP3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_Lpants3 = new System.Windows.Forms.Label();
            this.btn_addLP2 = new System.Windows.Forms.Button();
            this.lb_hargaLP2 = new System.Windows.Forms.Label();
            this.lb_Lpants2 = new System.Windows.Forms.Label();
            this.btn_addLP1 = new System.Windows.Forms.Button();
            this.lb_hargaLP1 = new System.Windows.Forms.Label();
            this.lb_Lpants1 = new System.Windows.Forms.Label();
            this.pb_Lpants3 = new System.Windows.Forms.PictureBox();
            this.pb_Lpants1 = new System.Windows.Forms.PictureBox();
            this.pb_Lpants2 = new System.Windows.Forms.PictureBox();
            this.panel_Lpants = new System.Windows.Forms.Panel();
            this.panel_shoes = new System.Windows.Forms.Panel();
            this.btn_addSh3 = new System.Windows.Forms.Button();
            this.lb_hargaSh3 = new System.Windows.Forms.Label();
            this.lb_shoes3 = new System.Windows.Forms.Label();
            this.btn_addSh2 = new System.Windows.Forms.Button();
            this.lb_hargaSh2 = new System.Windows.Forms.Label();
            this.lb_shoes2 = new System.Windows.Forms.Label();
            this.btn_addSh1 = new System.Windows.Forms.Button();
            this.lb_hargaSh1 = new System.Windows.Forms.Label();
            this.lb_shoes1 = new System.Windows.Forms.Label();
            this.pb_shoe3 = new System.Windows.Forms.PictureBox();
            this.pb_shoes2 = new System.Windows.Forms.PictureBox();
            this.pb_shoes1 = new System.Windows.Forms.PictureBox();
            this.panel_bracelet = new System.Windows.Forms.Panel();
            this.btn_addB3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_bracelet3 = new System.Windows.Forms.Label();
            this.btn_addB2 = new System.Windows.Forms.Button();
            this.lb_hargaB2 = new System.Windows.Forms.Label();
            this.lb_bracelet2 = new System.Windows.Forms.Label();
            this.btn_addB1 = new System.Windows.Forms.Button();
            this.lb_hargaB1 = new System.Windows.Forms.Label();
            this.lb_bracelet1 = new System.Windows.Forms.Label();
            this.pb_bracelet3 = new System.Windows.Forms.PictureBox();
            this.pb_bracelet2 = new System.Windows.Forms.PictureBox();
            this.pb_bracelet1 = new System.Windows.Forms.PictureBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.lb_upload = new System.Windows.Forms.Label();
            this.btn_upload = new System.Windows.Forms.Button();
            this.pb_upload = new System.Windows.Forms.PictureBox();
            this.lb_item = new System.Windows.Forms.Label();
            this.lb_price = new System.Windows.Forms.Label();
            this.tb_itemName = new System.Windows.Forms.TextBox();
            this.tb_price = new System.Windows.Forms.TextBox();
            this.btn_addUser = new System.Windows.Forms.Button();
            this.panel_others = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt3)).BeginInit();
            this.panel_tshirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt3)).BeginInit();
            this.panel_shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants1)).BeginInit();
            this.panel_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Lpants3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Lpants1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Lpants2)).BeginInit();
            this.panel_Lpants.SuspendLayout();
            this.panel_shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoe3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoes2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoes1)).BeginInit();
            this.panel_bracelet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bracelet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bracelet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bracelet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_upload)).BeginInit();
            this.panel_others.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1761, 40);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(134, 36);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(219, 44);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(219, 44);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(174, 36);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(263, 44);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(263, 44);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(155, 36);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(261, 44);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(261, 44);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(105, 36);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgv_cart
            // 
            this.dgv_cart.AllowUserToAddRows = false;
            this.dgv_cart.AllowUserToResizeRows = false;
            this.dgv_cart.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_cart.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_cart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_cart.Location = new System.Drawing.Point(769, 55);
            this.dgv_cart.MultiSelect = false;
            this.dgv_cart.Name = "dgv_cart";
            this.dgv_cart.ReadOnly = true;
            this.dgv_cart.RowHeadersVisible = false;
            this.dgv_cart.RowHeadersWidth = 82;
            this.dgv_cart.RowTemplate.Height = 33;
            this.dgv_cart.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_cart.Size = new System.Drawing.Size(654, 459);
            this.dgv_cart.TabIndex = 1;
            // 
            // lb_subtot
            // 
            this.lb_subtot.AutoSize = true;
            this.lb_subtot.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_subtot.Location = new System.Drawing.Point(762, 536);
            this.lb_subtot.Name = "lb_subtot";
            this.lb_subtot.Size = new System.Drawing.Size(175, 37);
            this.lb_subtot.TabIndex = 2;
            this.lb_subtot.Text = "Sub-Total:";
            // 
            // lb_total
            // 
            this.lb_total.AutoSize = true;
            this.lb_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_total.Location = new System.Drawing.Point(833, 585);
            this.lb_total.Name = "lb_total";
            this.lb_total.Size = new System.Drawing.Size(104, 37);
            this.lb_total.TabIndex = 3;
            this.lb_total.Text = "Total:";
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Location = new System.Drawing.Point(953, 541);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(216, 31);
            this.tb_subtotal.TabIndex = 4;
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(953, 591);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(216, 31);
            this.tb_total.TabIndex = 5;
            // 
            // pb_tshirt1
            // 
            this.pb_tshirt1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_tshirt1.BackgroundImage")));
            this.pb_tshirt1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_tshirt1.Location = new System.Drawing.Point(36, 30);
            this.pb_tshirt1.Name = "pb_tshirt1";
            this.pb_tshirt1.Size = new System.Drawing.Size(210, 303);
            this.pb_tshirt1.TabIndex = 6;
            this.pb_tshirt1.TabStop = false;
            // 
            // pb_tshirt2
            // 
            this.pb_tshirt2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_tshirt2.BackgroundImage")));
            this.pb_tshirt2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_tshirt2.Location = new System.Drawing.Point(278, 30);
            this.pb_tshirt2.Name = "pb_tshirt2";
            this.pb_tshirt2.Size = new System.Drawing.Size(210, 303);
            this.pb_tshirt2.TabIndex = 7;
            this.pb_tshirt2.TabStop = false;
            // 
            // pb_tshirt3
            // 
            this.pb_tshirt3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_tshirt3.BackgroundImage")));
            this.pb_tshirt3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_tshirt3.Location = new System.Drawing.Point(518, 30);
            this.pb_tshirt3.Name = "pb_tshirt3";
            this.pb_tshirt3.Size = new System.Drawing.Size(210, 303);
            this.pb_tshirt3.TabIndex = 8;
            this.pb_tshirt3.TabStop = false;
            // 
            // lb_tshirt1
            // 
            this.lb_tshirt1.AutoSize = true;
            this.lb_tshirt1.Location = new System.Drawing.Point(13, 347);
            this.lb_tshirt1.Name = "lb_tshirt1";
            this.lb_tshirt1.Size = new System.Drawing.Size(251, 25);
            this.lb_tshirt1.TabIndex = 9;
            this.lb_tshirt1.Text = "T-Shirt Garis Kerah Bulat";
            // 
            // lb_hargaT1
            // 
            this.lb_hargaT1.AutoSize = true;
            this.lb_hargaT1.Location = new System.Drawing.Point(60, 381);
            this.lb_hargaT1.Name = "lb_hargaT1";
            this.lb_hargaT1.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaT1.TabIndex = 10;
            this.lb_hargaT1.Text = "Rp. 199.000,-";
            // 
            // btn_addT1
            // 
            this.btn_addT1.Location = new System.Drawing.Point(53, 422);
            this.btn_addT1.Name = "btn_addT1";
            this.btn_addT1.Size = new System.Drawing.Size(154, 51);
            this.btn_addT1.TabIndex = 11;
            this.btn_addT1.Text = "Add To Cart";
            this.btn_addT1.UseVisualStyleBackColor = true;
            this.btn_addT1.Click += new System.EventHandler(this.btn_addT1_Click);
            // 
            // lb_tshirt2
            // 
            this.lb_tshirt2.AutoSize = true;
            this.lb_tshirt2.Location = new System.Drawing.Point(315, 347);
            this.lb_tshirt2.Name = "lb_tshirt2";
            this.lb_tshirt2.Size = new System.Drawing.Size(133, 25);
            this.lb_tshirt2.TabIndex = 12;
            this.lb_tshirt2.Text = "T-Shirt Kerut";
            // 
            // lb_hargaT2
            // 
            this.lb_hargaT2.AutoSize = true;
            this.lb_hargaT2.Location = new System.Drawing.Point(311, 381);
            this.lb_hargaT2.Name = "lb_hargaT2";
            this.lb_hargaT2.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaT2.TabIndex = 13;
            this.lb_hargaT2.Text = "Rp. 199.000,-";
            // 
            // btn_addT2
            // 
            this.btn_addT2.Location = new System.Drawing.Point(303, 422);
            this.btn_addT2.Name = "btn_addT2";
            this.btn_addT2.Size = new System.Drawing.Size(154, 51);
            this.btn_addT2.TabIndex = 14;
            this.btn_addT2.Text = "Add To Cart";
            this.btn_addT2.UseVisualStyleBackColor = true;
            this.btn_addT2.Click += new System.EventHandler(this.btn_addT2_Click);
            // 
            // lb_tshirt3
            // 
            this.lb_tshirt3.AutoSize = true;
            this.lb_tshirt3.Location = new System.Drawing.Point(559, 347);
            this.lb_tshirt3.Name = "lb_tshirt3";
            this.lb_tshirt3.Size = new System.Drawing.Size(138, 25);
            this.lb_tshirt3.TabIndex = 15;
            this.lb_tshirt3.Text = "T-Shirt Katun";
            // 
            // lb_hargaT3
            // 
            this.lb_hargaT3.AutoSize = true;
            this.lb_hargaT3.Location = new System.Drawing.Point(559, 381);
            this.lb_hargaT3.Name = "lb_hargaT3";
            this.lb_hargaT3.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaT3.TabIndex = 16;
            this.lb_hargaT3.Text = "Rp. 199.000,-";
            // 
            // btn_addT3
            // 
            this.btn_addT3.Location = new System.Drawing.Point(550, 422);
            this.btn_addT3.Name = "btn_addT3";
            this.btn_addT3.Size = new System.Drawing.Size(154, 51);
            this.btn_addT3.TabIndex = 17;
            this.btn_addT3.Text = "Add To Cart";
            this.btn_addT3.UseVisualStyleBackColor = true;
            this.btn_addT3.Click += new System.EventHandler(this.btn_addT3_Click);
            // 
            // panel_tshirt
            // 
            this.panel_tshirt.Controls.Add(this.btn_addT3);
            this.panel_tshirt.Controls.Add(this.lb_hargaT3);
            this.panel_tshirt.Controls.Add(this.lb_tshirt3);
            this.panel_tshirt.Controls.Add(this.btn_addT2);
            this.panel_tshirt.Controls.Add(this.lb_hargaT2);
            this.panel_tshirt.Controls.Add(this.lb_tshirt2);
            this.panel_tshirt.Controls.Add(this.btn_addT1);
            this.panel_tshirt.Controls.Add(this.lb_hargaT1);
            this.panel_tshirt.Controls.Add(this.lb_tshirt1);
            this.panel_tshirt.Controls.Add(this.pb_tshirt3);
            this.panel_tshirt.Controls.Add(this.pb_tshirt2);
            this.panel_tshirt.Controls.Add(this.pb_tshirt1);
            this.panel_tshirt.Location = new System.Drawing.Point(9, 55);
            this.panel_tshirt.Name = "panel_tshirt";
            this.panel_tshirt.Size = new System.Drawing.Size(744, 486);
            this.panel_tshirt.TabIndex = 18;
            // 
            // pb_shirt1
            // 
            this.pb_shirt1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_shirt1.BackgroundImage")));
            this.pb_shirt1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_shirt1.Location = new System.Drawing.Point(25, 16);
            this.pb_shirt1.Name = "pb_shirt1";
            this.pb_shirt1.Size = new System.Drawing.Size(210, 303);
            this.pb_shirt1.TabIndex = 18;
            this.pb_shirt1.TabStop = false;
            // 
            // pb_shirt2
            // 
            this.pb_shirt2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_shirt2.BackgroundImage")));
            this.pb_shirt2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_shirt2.Location = new System.Drawing.Point(267, 16);
            this.pb_shirt2.Name = "pb_shirt2";
            this.pb_shirt2.Size = new System.Drawing.Size(210, 303);
            this.pb_shirt2.TabIndex = 19;
            this.pb_shirt2.TabStop = false;
            // 
            // pb_shirt3
            // 
            this.pb_shirt3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_shirt3.BackgroundImage")));
            this.pb_shirt3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_shirt3.Location = new System.Drawing.Point(507, 16);
            this.pb_shirt3.Name = "pb_shirt3";
            this.pb_shirt3.Size = new System.Drawing.Size(210, 303);
            this.pb_shirt3.TabIndex = 20;
            this.pb_shirt3.TabStop = false;
            // 
            // lb_shirt1
            // 
            this.lb_shirt1.AutoSize = true;
            this.lb_shirt1.Location = new System.Drawing.Point(44, 335);
            this.lb_shirt1.Name = "lb_shirt1";
            this.lb_shirt1.Size = new System.Drawing.Size(172, 25);
            this.lb_shirt1.TabIndex = 18;
            this.lb_shirt1.Text = "Kaos Polo Katun";
            // 
            // lb_hargaS1
            // 
            this.lb_hargaS1.AutoSize = true;
            this.lb_hargaS1.Location = new System.Drawing.Point(56, 365);
            this.lb_hargaS1.Name = "lb_hargaS1";
            this.lb_hargaS1.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaS1.TabIndex = 18;
            this.lb_hargaS1.Text = "Rp. 299.000,-";
            // 
            // btn_addS1
            // 
            this.btn_addS1.Location = new System.Drawing.Point(49, 408);
            this.btn_addS1.Name = "btn_addS1";
            this.btn_addS1.Size = new System.Drawing.Size(154, 51);
            this.btn_addS1.TabIndex = 18;
            this.btn_addS1.Text = "Add To Cart";
            this.btn_addS1.UseVisualStyleBackColor = true;
            this.btn_addS1.Click += new System.EventHandler(this.btn_addS1_Click);
            // 
            // lb_shirt2
            // 
            this.lb_shirt2.AutoSize = true;
            this.lb_shirt2.Location = new System.Drawing.Point(300, 335);
            this.lb_shirt2.Name = "lb_shirt2";
            this.lb_shirt2.Size = new System.Drawing.Size(149, 25);
            this.lb_shirt2.TabIndex = 21;
            this.lb_shirt2.Text = "Kaos Polo Dry";
            // 
            // lb_hargaS2
            // 
            this.lb_hargaS2.AutoSize = true;
            this.lb_hargaS2.Location = new System.Drawing.Point(304, 365);
            this.lb_hargaS2.Name = "lb_hargaS2";
            this.lb_hargaS2.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaS2.TabIndex = 22;
            this.lb_hargaS2.Text = "Rp. 299.000,-";
            // 
            // btn_addS2
            // 
            this.btn_addS2.Location = new System.Drawing.Point(296, 408);
            this.btn_addS2.Name = "btn_addS2";
            this.btn_addS2.Size = new System.Drawing.Size(154, 51);
            this.btn_addS2.TabIndex = 23;
            this.btn_addS2.Text = "Add To Cart";
            this.btn_addS2.UseVisualStyleBackColor = true;
            this.btn_addS2.Click += new System.EventHandler(this.btn_addS2_Click);
            // 
            // lb_shirt3
            // 
            this.lb_shirt3.AutoSize = true;
            this.lb_shirt3.Location = new System.Drawing.Point(526, 335);
            this.lb_shirt3.Name = "lb_shirt3";
            this.lb_shirt3.Size = new System.Drawing.Size(166, 25);
            this.lb_shirt3.TabIndex = 24;
            this.lb_shirt3.Text = "Kaos Polo Rajut";
            // 
            // lb_hargaS3
            // 
            this.lb_hargaS3.AutoSize = true;
            this.lb_hargaS3.Location = new System.Drawing.Point(534, 365);
            this.lb_hargaS3.Name = "lb_hargaS3";
            this.lb_hargaS3.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaS3.TabIndex = 25;
            this.lb_hargaS3.Text = "Rp. 599.000,-";
            // 
            // btn_addS3
            // 
            this.btn_addS3.Location = new System.Drawing.Point(529, 408);
            this.btn_addS3.Name = "btn_addS3";
            this.btn_addS3.Size = new System.Drawing.Size(154, 51);
            this.btn_addS3.TabIndex = 26;
            this.btn_addS3.Text = "Add To Cart";
            this.btn_addS3.UseVisualStyleBackColor = true;
            this.btn_addS3.Click += new System.EventHandler(this.btn_addS3_Click);
            // 
            // panel_shirt
            // 
            this.panel_shirt.Controls.Add(this.btn_addS3);
            this.panel_shirt.Controls.Add(this.lb_hargaS3);
            this.panel_shirt.Controls.Add(this.lb_shirt3);
            this.panel_shirt.Controls.Add(this.btn_addS2);
            this.panel_shirt.Controls.Add(this.lb_hargaS2);
            this.panel_shirt.Controls.Add(this.lb_shirt2);
            this.panel_shirt.Controls.Add(this.btn_addS1);
            this.panel_shirt.Controls.Add(this.lb_hargaS1);
            this.panel_shirt.Controls.Add(this.lb_shirt1);
            this.panel_shirt.Controls.Add(this.pb_shirt3);
            this.panel_shirt.Controls.Add(this.pb_shirt2);
            this.panel_shirt.Controls.Add(this.pb_shirt1);
            this.panel_shirt.Location = new System.Drawing.Point(12, 55);
            this.panel_shirt.Name = "panel_shirt";
            this.panel_shirt.Size = new System.Drawing.Size(749, 499);
            this.panel_shirt.TabIndex = 27;
            // 
            // btn_addP3
            // 
            this.btn_addP3.Location = new System.Drawing.Point(514, 412);
            this.btn_addP3.Name = "btn_addP3";
            this.btn_addP3.Size = new System.Drawing.Size(154, 51);
            this.btn_addP3.TabIndex = 38;
            this.btn_addP3.Text = "Add To Cart";
            this.btn_addP3.UseVisualStyleBackColor = true;
            this.btn_addP3.Click += new System.EventHandler(this.btn_addP3_Click);
            // 
            // lb_hargaP3
            // 
            this.lb_hargaP3.AutoSize = true;
            this.lb_hargaP3.Location = new System.Drawing.Point(519, 369);
            this.lb_hargaP3.Name = "lb_hargaP3";
            this.lb_hargaP3.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaP3.TabIndex = 37;
            this.lb_hargaP3.Text = "Rp. 399.000,-";
            // 
            // lb_pants3
            // 
            this.lb_pants3.AutoSize = true;
            this.lb_pants3.Location = new System.Drawing.Point(487, 339);
            this.lb_pants3.Name = "lb_pants3";
            this.lb_pants3.Size = new System.Drawing.Size(221, 25);
            this.lb_pants3.TabIndex = 36;
            this.lb_pants3.Text = "Celana Pendek Katun";
            // 
            // btn_addP2
            // 
            this.btn_addP2.Location = new System.Drawing.Point(281, 412);
            this.btn_addP2.Name = "btn_addP2";
            this.btn_addP2.Size = new System.Drawing.Size(154, 51);
            this.btn_addP2.TabIndex = 35;
            this.btn_addP2.Text = "Add To Cart";
            this.btn_addP2.UseVisualStyleBackColor = true;
            this.btn_addP2.Click += new System.EventHandler(this.btn_addP2_Click);
            // 
            // lb_hargaP2
            // 
            this.lb_hargaP2.AutoSize = true;
            this.lb_hargaP2.Location = new System.Drawing.Point(289, 369);
            this.lb_hargaP2.Name = "lb_hargaP2";
            this.lb_hargaP2.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaP2.TabIndex = 34;
            this.lb_hargaP2.Text = "Rp. 399.000,-";
            // 
            // lb_pants2
            // 
            this.lb_pants2.AutoSize = true;
            this.lb_pants2.Location = new System.Drawing.Point(247, 339);
            this.lb_pants2.Name = "lb_pants2";
            this.lb_pants2.Size = new System.Drawing.Size(222, 25);
            this.lb_pants2.TabIndex = 33;
            this.lb_pants2.Text = "Celana Pendek Kargo";
            // 
            // btn_addP1
            // 
            this.btn_addP1.Location = new System.Drawing.Point(34, 412);
            this.btn_addP1.Name = "btn_addP1";
            this.btn_addP1.Size = new System.Drawing.Size(154, 51);
            this.btn_addP1.TabIndex = 27;
            this.btn_addP1.Text = "Add To Cart";
            this.btn_addP1.UseVisualStyleBackColor = true;
            this.btn_addP1.Click += new System.EventHandler(this.btn_addP1_Click);
            // 
            // lb_hargaP1
            // 
            this.lb_hargaP1.AutoSize = true;
            this.lb_hargaP1.Location = new System.Drawing.Point(41, 369);
            this.lb_hargaP1.Name = "lb_hargaP1";
            this.lb_hargaP1.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaP1.TabIndex = 28;
            this.lb_hargaP1.Text = "Rp. 399.000,-";
            // 
            // lb_pants1
            // 
            this.lb_pants1.AutoSize = true;
            this.lb_pants1.Location = new System.Drawing.Point(5, 339);
            this.lb_pants1.Name = "lb_pants1";
            this.lb_pants1.Size = new System.Drawing.Size(226, 25);
            this.lb_pants1.TabIndex = 29;
            this.lb_pants1.Text = "Celana Pendek Denim";
            // 
            // pb_pants3
            // 
            this.pb_pants3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_pants3.BackgroundImage")));
            this.pb_pants3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_pants3.Location = new System.Drawing.Point(492, 20);
            this.pb_pants3.Name = "pb_pants3";
            this.pb_pants3.Size = new System.Drawing.Size(210, 303);
            this.pb_pants3.TabIndex = 32;
            this.pb_pants3.TabStop = false;
            // 
            // pb_pants2
            // 
            this.pb_pants2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_pants2.BackgroundImage")));
            this.pb_pants2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_pants2.Location = new System.Drawing.Point(252, 20);
            this.pb_pants2.Name = "pb_pants2";
            this.pb_pants2.Size = new System.Drawing.Size(210, 303);
            this.pb_pants2.TabIndex = 31;
            this.pb_pants2.TabStop = false;
            // 
            // pb_pants1
            // 
            this.pb_pants1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_pants1.BackgroundImage")));
            this.pb_pants1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_pants1.Location = new System.Drawing.Point(10, 20);
            this.pb_pants1.Name = "pb_pants1";
            this.pb_pants1.Size = new System.Drawing.Size(210, 303);
            this.pb_pants1.TabIndex = 30;
            this.pb_pants1.TabStop = false;
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.btn_addP3);
            this.panel_pants.Controls.Add(this.lb_hargaP3);
            this.panel_pants.Controls.Add(this.lb_pants3);
            this.panel_pants.Controls.Add(this.btn_addP2);
            this.panel_pants.Controls.Add(this.lb_hargaP2);
            this.panel_pants.Controls.Add(this.lb_pants2);
            this.panel_pants.Controls.Add(this.btn_addP1);
            this.panel_pants.Controls.Add(this.lb_hargaP1);
            this.panel_pants.Controls.Add(this.lb_pants1);
            this.panel_pants.Controls.Add(this.pb_pants3);
            this.panel_pants.Controls.Add(this.pb_pants1);
            this.panel_pants.Controls.Add(this.pb_pants2);
            this.panel_pants.Location = new System.Drawing.Point(13, 55);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(743, 493);
            this.panel_pants.TabIndex = 39;
            // 
            // btn_addLP3
            // 
            this.btn_addLP3.Location = new System.Drawing.Point(532, 414);
            this.btn_addLP3.Name = "btn_addLP3";
            this.btn_addLP3.Size = new System.Drawing.Size(154, 51);
            this.btn_addLP3.TabIndex = 50;
            this.btn_addLP3.Text = "Add To Cart";
            this.btn_addLP3.UseVisualStyleBackColor = true;
            this.btn_addLP3.Click += new System.EventHandler(this.btn_addLP3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(537, 371);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 25);
            this.label1.TabIndex = 49;
            this.label1.Text = "Rp. 399.000,-";
            // 
            // lb_Lpants3
            // 
            this.lb_Lpants3.AutoSize = true;
            this.lb_Lpants3.Location = new System.Drawing.Point(534, 341);
            this.lb_Lpants3.Name = "lb_Lpants3";
            this.lb_Lpants3.Size = new System.Drawing.Size(140, 25);
            this.lb_Lpants3.TabIndex = 48;
            this.lb_Lpants3.Text = "Celana Lurus";
            // 
            // btn_addLP2
            // 
            this.btn_addLP2.Location = new System.Drawing.Point(291, 414);
            this.btn_addLP2.Name = "btn_addLP2";
            this.btn_addLP2.Size = new System.Drawing.Size(154, 51);
            this.btn_addLP2.TabIndex = 47;
            this.btn_addLP2.Text = "Add To Cart";
            this.btn_addLP2.UseVisualStyleBackColor = true;
            this.btn_addLP2.Click += new System.EventHandler(this.btn_addLP2_Click);
            // 
            // lb_hargaLP2
            // 
            this.lb_hargaLP2.AutoSize = true;
            this.lb_hargaLP2.Location = new System.Drawing.Point(297, 371);
            this.lb_hargaLP2.Name = "lb_hargaLP2";
            this.lb_hargaLP2.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaLP2.TabIndex = 46;
            this.lb_hargaLP2.Text = "Rp. 499.000,-";
            // 
            // lb_Lpants2
            // 
            this.lb_Lpants2.AutoSize = true;
            this.lb_Lpants2.Location = new System.Drawing.Point(297, 341);
            this.lb_Lpants2.Name = "lb_Lpants2";
            this.lb_Lpants2.Size = new System.Drawing.Size(140, 25);
            this.lb_Lpants2.TabIndex = 45;
            this.lb_Lpants2.Text = "Celana Ankle";
            // 
            // btn_addLP1
            // 
            this.btn_addLP1.Location = new System.Drawing.Point(42, 414);
            this.btn_addLP1.Name = "btn_addLP1";
            this.btn_addLP1.Size = new System.Drawing.Size(154, 51);
            this.btn_addLP1.TabIndex = 39;
            this.btn_addLP1.Text = "Add To Cart";
            this.btn_addLP1.UseVisualStyleBackColor = true;
            this.btn_addLP1.Click += new System.EventHandler(this.btn_addLP1_Click);
            // 
            // lb_hargaLP1
            // 
            this.lb_hargaLP1.AutoSize = true;
            this.lb_hargaLP1.Location = new System.Drawing.Point(52, 371);
            this.lb_hargaLP1.Name = "lb_hargaLP1";
            this.lb_hargaLP1.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaLP1.TabIndex = 40;
            this.lb_hargaLP1.Text = "Rp. 499.000,-";
            // 
            // lb_Lpants1
            // 
            this.lb_Lpants1.AutoSize = true;
            this.lb_Lpants1.Location = new System.Drawing.Point(42, 341);
            this.lb_Lpants1.Name = "lb_Lpants1";
            this.lb_Lpants1.Size = new System.Drawing.Size(178, 25);
            this.lb_Lpants1.TabIndex = 41;
            this.lb_Lpants1.Text = "Celana Tappered";
            // 
            // pb_Lpants3
            // 
            this.pb_Lpants3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_Lpants3.BackgroundImage")));
            this.pb_Lpants3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_Lpants3.Location = new System.Drawing.Point(500, 22);
            this.pb_Lpants3.Name = "pb_Lpants3";
            this.pb_Lpants3.Size = new System.Drawing.Size(210, 303);
            this.pb_Lpants3.TabIndex = 44;
            this.pb_Lpants3.TabStop = false;
            // 
            // pb_Lpants1
            // 
            this.pb_Lpants1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_Lpants1.BackgroundImage")));
            this.pb_Lpants1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_Lpants1.Location = new System.Drawing.Point(18, 22);
            this.pb_Lpants1.Name = "pb_Lpants1";
            this.pb_Lpants1.Size = new System.Drawing.Size(210, 303);
            this.pb_Lpants1.TabIndex = 42;
            this.pb_Lpants1.TabStop = false;
            // 
            // pb_Lpants2
            // 
            this.pb_Lpants2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_Lpants2.BackgroundImage")));
            this.pb_Lpants2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_Lpants2.Location = new System.Drawing.Point(260, 22);
            this.pb_Lpants2.Name = "pb_Lpants2";
            this.pb_Lpants2.Size = new System.Drawing.Size(210, 303);
            this.pb_Lpants2.TabIndex = 43;
            this.pb_Lpants2.TabStop = false;
            // 
            // panel_Lpants
            // 
            this.panel_Lpants.Controls.Add(this.btn_addLP3);
            this.panel_Lpants.Controls.Add(this.label1);
            this.panel_Lpants.Controls.Add(this.lb_Lpants3);
            this.panel_Lpants.Controls.Add(this.btn_addLP2);
            this.panel_Lpants.Controls.Add(this.lb_hargaLP2);
            this.panel_Lpants.Controls.Add(this.lb_Lpants2);
            this.panel_Lpants.Controls.Add(this.btn_addLP1);
            this.panel_Lpants.Controls.Add(this.lb_hargaLP1);
            this.panel_Lpants.Controls.Add(this.lb_Lpants1);
            this.panel_Lpants.Controls.Add(this.pb_Lpants3);
            this.panel_Lpants.Controls.Add(this.pb_Lpants2);
            this.panel_Lpants.Controls.Add(this.pb_Lpants1);
            this.panel_Lpants.Location = new System.Drawing.Point(9, 55);
            this.panel_Lpants.Name = "panel_Lpants";
            this.panel_Lpants.Size = new System.Drawing.Size(770, 493);
            this.panel_Lpants.TabIndex = 51;
            // 
            // panel_shoes
            // 
            this.panel_shoes.Controls.Add(this.btn_addSh3);
            this.panel_shoes.Controls.Add(this.lb_hargaSh3);
            this.panel_shoes.Controls.Add(this.lb_shoes3);
            this.panel_shoes.Controls.Add(this.btn_addSh2);
            this.panel_shoes.Controls.Add(this.lb_hargaSh2);
            this.panel_shoes.Controls.Add(this.lb_shoes2);
            this.panel_shoes.Controls.Add(this.btn_addSh1);
            this.panel_shoes.Controls.Add(this.lb_hargaSh1);
            this.panel_shoes.Controls.Add(this.lb_shoes1);
            this.panel_shoes.Controls.Add(this.pb_shoe3);
            this.panel_shoes.Controls.Add(this.pb_shoes2);
            this.panel_shoes.Controls.Add(this.pb_shoes1);
            this.panel_shoes.Location = new System.Drawing.Point(6, 55);
            this.panel_shoes.Name = "panel_shoes";
            this.panel_shoes.Size = new System.Drawing.Size(770, 493);
            this.panel_shoes.TabIndex = 52;
            // 
            // btn_addSh3
            // 
            this.btn_addSh3.Location = new System.Drawing.Point(532, 414);
            this.btn_addSh3.Name = "btn_addSh3";
            this.btn_addSh3.Size = new System.Drawing.Size(154, 51);
            this.btn_addSh3.TabIndex = 50;
            this.btn_addSh3.Text = "Add To Cart";
            this.btn_addSh3.UseVisualStyleBackColor = true;
            this.btn_addSh3.Click += new System.EventHandler(this.btn_addSh3_Click);
            // 
            // lb_hargaSh3
            // 
            this.lb_hargaSh3.AutoSize = true;
            this.lb_hargaSh3.Location = new System.Drawing.Point(531, 373);
            this.lb_hargaSh3.Name = "lb_hargaSh3";
            this.lb_hargaSh3.Size = new System.Drawing.Size(160, 25);
            this.lb_hargaSh3.TabIndex = 49;
            this.lb_hargaSh3.Text = "Rp. 1.499.000,-";
            // 
            // lb_shoes3
            // 
            this.lb_shoes3.AutoSize = true;
            this.lb_shoes3.Location = new System.Drawing.Point(563, 341);
            this.lb_shoes3.Name = "lb_shoes3";
            this.lb_shoes3.Size = new System.Drawing.Size(85, 25);
            this.lb_shoes3.TabIndex = 48;
            this.lb_shoes3.Text = "Air Max";
            // 
            // btn_addSh2
            // 
            this.btn_addSh2.Location = new System.Drawing.Point(291, 414);
            this.btn_addSh2.Name = "btn_addSh2";
            this.btn_addSh2.Size = new System.Drawing.Size(154, 51);
            this.btn_addSh2.TabIndex = 47;
            this.btn_addSh2.Text = "Add To Cart";
            this.btn_addSh2.UseVisualStyleBackColor = true;
            this.btn_addSh2.Click += new System.EventHandler(this.btn_addSh2_Click);
            // 
            // lb_hargaSh2
            // 
            this.lb_hargaSh2.AutoSize = true;
            this.lb_hargaSh2.Location = new System.Drawing.Point(297, 371);
            this.lb_hargaSh2.Name = "lb_hargaSh2";
            this.lb_hargaSh2.Size = new System.Drawing.Size(160, 25);
            this.lb_hargaSh2.TabIndex = 46;
            this.lb_hargaSh2.Text = "Rp. 1.549.000,-";
            // 
            // lb_shoes2
            // 
            this.lb_shoes2.AutoSize = true;
            this.lb_shoes2.Location = new System.Drawing.Point(320, 341);
            this.lb_shoes2.Name = "lb_shoes2";
            this.lb_shoes2.Size = new System.Drawing.Size(99, 25);
            this.lb_shoes2.TabIndex = 45;
            this.lb_shoes2.Text = "Air Force";
            // 
            // btn_addSh1
            // 
            this.btn_addSh1.Location = new System.Drawing.Point(50, 414);
            this.btn_addSh1.Name = "btn_addSh1";
            this.btn_addSh1.Size = new System.Drawing.Size(154, 51);
            this.btn_addSh1.TabIndex = 39;
            this.btn_addSh1.Text = "Add To Cart";
            this.btn_addSh1.UseVisualStyleBackColor = true;
            this.btn_addSh1.Click += new System.EventHandler(this.btn_addSh1_Click);
            // 
            // lb_hargaSh1
            // 
            this.lb_hargaSh1.AutoSize = true;
            this.lb_hargaSh1.Location = new System.Drawing.Point(49, 371);
            this.lb_hargaSh1.Name = "lb_hargaSh1";
            this.lb_hargaSh1.Size = new System.Drawing.Size(160, 25);
            this.lb_hargaSh1.TabIndex = 40;
            this.lb_hargaSh1.Text = "Rp. 2.129.000,-";
            // 
            // lb_shoes1
            // 
            this.lb_shoes1.AutoSize = true;
            this.lb_shoes1.Location = new System.Drawing.Point(73, 341);
            this.lb_shoes1.Name = "lb_shoes1";
            this.lb_shoes1.Size = new System.Drawing.Size(110, 25);
            this.lb_shoes1.TabIndex = 41;
            this.lb_shoes1.Text = "Air Jordan";
            // 
            // pb_shoe3
            // 
            this.pb_shoe3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_shoe3.BackgroundImage")));
            this.pb_shoe3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_shoe3.Location = new System.Drawing.Point(500, 22);
            this.pb_shoe3.Name = "pb_shoe3";
            this.pb_shoe3.Size = new System.Drawing.Size(210, 303);
            this.pb_shoe3.TabIndex = 44;
            this.pb_shoe3.TabStop = false;
            // 
            // pb_shoes2
            // 
            this.pb_shoes2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_shoes2.BackgroundImage")));
            this.pb_shoes2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_shoes2.Location = new System.Drawing.Point(260, 22);
            this.pb_shoes2.Name = "pb_shoes2";
            this.pb_shoes2.Size = new System.Drawing.Size(210, 303);
            this.pb_shoes2.TabIndex = 43;
            this.pb_shoes2.TabStop = false;
            // 
            // pb_shoes1
            // 
            this.pb_shoes1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_shoes1.BackgroundImage")));
            this.pb_shoes1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_shoes1.Location = new System.Drawing.Point(18, 22);
            this.pb_shoes1.Name = "pb_shoes1";
            this.pb_shoes1.Size = new System.Drawing.Size(210, 303);
            this.pb_shoes1.TabIndex = 42;
            this.pb_shoes1.TabStop = false;
            // 
            // panel_bracelet
            // 
            this.panel_bracelet.Controls.Add(this.btn_addB3);
            this.panel_bracelet.Controls.Add(this.label2);
            this.panel_bracelet.Controls.Add(this.lb_bracelet3);
            this.panel_bracelet.Controls.Add(this.btn_addB2);
            this.panel_bracelet.Controls.Add(this.lb_hargaB2);
            this.panel_bracelet.Controls.Add(this.lb_bracelet2);
            this.panel_bracelet.Controls.Add(this.btn_addB1);
            this.panel_bracelet.Controls.Add(this.lb_hargaB1);
            this.panel_bracelet.Controls.Add(this.lb_bracelet1);
            this.panel_bracelet.Controls.Add(this.pb_bracelet3);
            this.panel_bracelet.Controls.Add(this.pb_bracelet2);
            this.panel_bracelet.Controls.Add(this.pb_bracelet1);
            this.panel_bracelet.Location = new System.Drawing.Point(3, 55);
            this.panel_bracelet.Name = "panel_bracelet";
            this.panel_bracelet.Size = new System.Drawing.Size(770, 493);
            this.panel_bracelet.TabIndex = 53;
            // 
            // btn_addB3
            // 
            this.btn_addB3.Location = new System.Drawing.Point(532, 414);
            this.btn_addB3.Name = "btn_addB3";
            this.btn_addB3.Size = new System.Drawing.Size(154, 51);
            this.btn_addB3.TabIndex = 50;
            this.btn_addB3.Text = "Add To Cart";
            this.btn_addB3.UseVisualStyleBackColor = true;
            this.btn_addB3.Click += new System.EventHandler(this.btn_addB3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(531, 373);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 25);
            this.label2.TabIndex = 49;
            this.label2.Text = "Rp. 700.000,-";
            // 
            // lb_bracelet3
            // 
            this.lb_bracelet3.AutoSize = true;
            this.lb_bracelet3.Location = new System.Drawing.Point(521, 341);
            this.lb_bracelet3.Name = "lb_bracelet3";
            this.lb_bracelet3.Size = new System.Drawing.Size(170, 25);
            this.lb_bracelet3.TabIndex = 48;
            this.lb_bracelet3.Text = "Leather Bracelet";
            // 
            // btn_addB2
            // 
            this.btn_addB2.Location = new System.Drawing.Point(291, 414);
            this.btn_addB2.Name = "btn_addB2";
            this.btn_addB2.Size = new System.Drawing.Size(154, 51);
            this.btn_addB2.TabIndex = 47;
            this.btn_addB2.Text = "Add To Cart";
            this.btn_addB2.UseVisualStyleBackColor = true;
            this.btn_addB2.Click += new System.EventHandler(this.btn_addB2_Click);
            // 
            // lb_hargaB2
            // 
            this.lb_hargaB2.AutoSize = true;
            this.lb_hargaB2.Location = new System.Drawing.Point(297, 371);
            this.lb_hargaB2.Name = "lb_hargaB2";
            this.lb_hargaB2.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaB2.TabIndex = 46;
            this.lb_hargaB2.Text = "Rp. 750.000,-";
            // 
            // lb_bracelet2
            // 
            this.lb_bracelet2.AutoSize = true;
            this.lb_bracelet2.Location = new System.Drawing.Point(292, 341);
            this.lb_bracelet2.Name = "lb_bracelet2";
            this.lb_bracelet2.Size = new System.Drawing.Size(153, 25);
            this.lb_bracelet2.TabIndex = 45;
            this.lb_bracelet2.Text = "Chain Bracelet";
            // 
            // btn_addB1
            // 
            this.btn_addB1.Location = new System.Drawing.Point(50, 414);
            this.btn_addB1.Name = "btn_addB1";
            this.btn_addB1.Size = new System.Drawing.Size(154, 51);
            this.btn_addB1.TabIndex = 39;
            this.btn_addB1.Text = "Add To Cart";
            this.btn_addB1.UseVisualStyleBackColor = true;
            this.btn_addB1.Click += new System.EventHandler(this.btn_addB1_Click);
            // 
            // lb_hargaB1
            // 
            this.lb_hargaB1.AutoSize = true;
            this.lb_hargaB1.Location = new System.Drawing.Point(57, 371);
            this.lb_hargaB1.Name = "lb_hargaB1";
            this.lb_hargaB1.Size = new System.Drawing.Size(142, 25);
            this.lb_hargaB1.TabIndex = 40;
            this.lb_hargaB1.Text = "Rp. 500.000,-";
            // 
            // lb_bracelet1
            // 
            this.lb_bracelet1.AutoSize = true;
            this.lb_bracelet1.Location = new System.Drawing.Point(57, 341);
            this.lb_bracelet1.Name = "lb_bracelet1";
            this.lb_bracelet1.Size = new System.Drawing.Size(139, 25);
            this.lb_bracelet1.TabIndex = 41;
            this.lb_bracelet1.Text = "Pink Bracelet";
            // 
            // pb_bracelet3
            // 
            this.pb_bracelet3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_bracelet3.BackgroundImage")));
            this.pb_bracelet3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_bracelet3.Location = new System.Drawing.Point(500, 22);
            this.pb_bracelet3.Name = "pb_bracelet3";
            this.pb_bracelet3.Size = new System.Drawing.Size(210, 303);
            this.pb_bracelet3.TabIndex = 44;
            this.pb_bracelet3.TabStop = false;
            // 
            // pb_bracelet2
            // 
            this.pb_bracelet2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_bracelet2.BackgroundImage")));
            this.pb_bracelet2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_bracelet2.Location = new System.Drawing.Point(260, 22);
            this.pb_bracelet2.Name = "pb_bracelet2";
            this.pb_bracelet2.Size = new System.Drawing.Size(210, 303);
            this.pb_bracelet2.TabIndex = 43;
            this.pb_bracelet2.TabStop = false;
            // 
            // pb_bracelet1
            // 
            this.pb_bracelet1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_bracelet1.BackgroundImage")));
            this.pb_bracelet1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_bracelet1.Location = new System.Drawing.Point(18, 22);
            this.pb_bracelet1.Name = "pb_bracelet1";
            this.pb_bracelet1.Size = new System.Drawing.Size(210, 303);
            this.pb_bracelet1.TabIndex = 42;
            this.pb_bracelet1.TabStop = false;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1228, 541);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(110, 46);
            this.btn_delete.TabIndex = 54;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // lb_upload
            // 
            this.lb_upload.AutoSize = true;
            this.lb_upload.Location = new System.Drawing.Point(17, 13);
            this.lb_upload.Name = "lb_upload";
            this.lb_upload.Size = new System.Drawing.Size(144, 25);
            this.lb_upload.TabIndex = 55;
            this.lb_upload.Text = "Upload Image";
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(195, 13);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(178, 41);
            this.btn_upload.TabIndex = 56;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // pb_upload
            // 
            this.pb_upload.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_upload.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_upload.Location = new System.Drawing.Point(25, 81);
            this.pb_upload.Name = "pb_upload";
            this.pb_upload.Size = new System.Drawing.Size(222, 327);
            this.pb_upload.TabIndex = 57;
            this.pb_upload.TabStop = false;
            // 
            // lb_item
            // 
            this.lb_item.AutoSize = true;
            this.lb_item.Location = new System.Drawing.Point(287, 96);
            this.lb_item.Name = "lb_item";
            this.lb_item.Size = new System.Drawing.Size(120, 25);
            this.lb_item.TabIndex = 61;
            this.lb_item.Text = "Item Name:";
            // 
            // lb_price
            // 
            this.lb_price.AutoSize = true;
            this.lb_price.Location = new System.Drawing.Point(287, 180);
            this.lb_price.Name = "lb_price";
            this.lb_price.Size = new System.Drawing.Size(113, 25);
            this.lb_price.TabIndex = 63;
            this.lb_price.Text = "Item Price:";
            // 
            // tb_itemName
            // 
            this.tb_itemName.Location = new System.Drawing.Point(288, 125);
            this.tb_itemName.Name = "tb_itemName";
            this.tb_itemName.Size = new System.Drawing.Size(197, 31);
            this.tb_itemName.TabIndex = 0;
            this.tb_itemName.TextChanged += new System.EventHandler(this.tb_itemName_TextChanged);
            // 
            // tb_price
            // 
            this.tb_price.Location = new System.Drawing.Point(288, 208);
            this.tb_price.Name = "tb_price";
            this.tb_price.Size = new System.Drawing.Size(197, 31);
            this.tb_price.TabIndex = 64;
            this.tb_price.TextChanged += new System.EventHandler(this.tb_price_TextChanged);
            this.tb_price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_price_KeyPress);
            // 
            // btn_addUser
            // 
            this.btn_addUser.Location = new System.Drawing.Point(288, 369);
            this.btn_addUser.Name = "btn_addUser";
            this.btn_addUser.Size = new System.Drawing.Size(197, 39);
            this.btn_addUser.TabIndex = 65;
            this.btn_addUser.Text = "Add To Cart";
            this.btn_addUser.UseVisualStyleBackColor = true;
            this.btn_addUser.Click += new System.EventHandler(this.btn_addUser_Click);
            // 
            // panel_others
            // 
            this.panel_others.Controls.Add(this.btn_addUser);
            this.panel_others.Controls.Add(this.tb_price);
            this.panel_others.Controls.Add(this.tb_itemName);
            this.panel_others.Controls.Add(this.lb_price);
            this.panel_others.Controls.Add(this.lb_item);
            this.panel_others.Controls.Add(this.pb_upload);
            this.panel_others.Controls.Add(this.btn_upload);
            this.panel_others.Controls.Add(this.lb_upload);
            this.panel_others.Location = new System.Drawing.Point(6, 43);
            this.panel_others.Name = "panel_others";
            this.panel_others.Size = new System.Drawing.Size(602, 429);
            this.panel_others.TabIndex = 66;
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1761, 1559);
            this.Controls.Add(this.panel_others);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.panel_bracelet);
            this.Controls.Add(this.panel_shoes);
            this.Controls.Add(this.panel_Lpants);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.panel_shirt);
            this.Controls.Add(this.panel_tshirt);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.lb_total);
            this.Controls.Add(this.lb_subtot);
            this.Controls.Add(this.dgv_cart);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form_Main";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.Form_Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt3)).EndInit();
            this.panel_tshirt.ResumeLayout(false);
            this.panel_tshirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shirt3)).EndInit();
            this.panel_shirt.ResumeLayout(false);
            this.panel_shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants1)).EndInit();
            this.panel_pants.ResumeLayout(false);
            this.panel_pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Lpants3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Lpants1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Lpants2)).EndInit();
            this.panel_Lpants.ResumeLayout(false);
            this.panel_Lpants.PerformLayout();
            this.panel_shoes.ResumeLayout(false);
            this.panel_shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoe3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoes2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shoes1)).EndInit();
            this.panel_bracelet.ResumeLayout(false);
            this.panel_bracelet.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bracelet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bracelet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bracelet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_upload)).EndInit();
            this.panel_others.ResumeLayout(false);
            this.panel_others.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_cart;
        private System.Windows.Forms.Label lb_subtot;
        private System.Windows.Forms.Label lb_total;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.PictureBox pb_tshirt1;
        private System.Windows.Forms.PictureBox pb_tshirt2;
        private System.Windows.Forms.PictureBox pb_tshirt3;
        private System.Windows.Forms.Label lb_tshirt1;
        private System.Windows.Forms.Label lb_hargaT1;
        private System.Windows.Forms.Button btn_addT1;
        private System.Windows.Forms.Label lb_tshirt2;
        private System.Windows.Forms.Label lb_hargaT2;
        private System.Windows.Forms.Button btn_addT2;
        private System.Windows.Forms.Label lb_tshirt3;
        private System.Windows.Forms.Label lb_hargaT3;
        private System.Windows.Forms.Button btn_addT3;
        private System.Windows.Forms.Panel panel_tshirt;
        private System.Windows.Forms.PictureBox pb_shirt1;
        private System.Windows.Forms.PictureBox pb_shirt2;
        private System.Windows.Forms.PictureBox pb_shirt3;
        private System.Windows.Forms.Label lb_shirt1;
        private System.Windows.Forms.Label lb_hargaS1;
        private System.Windows.Forms.Button btn_addS1;
        private System.Windows.Forms.Label lb_shirt2;
        private System.Windows.Forms.Label lb_hargaS2;
        private System.Windows.Forms.Button btn_addS2;
        private System.Windows.Forms.Label lb_shirt3;
        private System.Windows.Forms.Label lb_hargaS3;
        private System.Windows.Forms.Button btn_addS3;
        private System.Windows.Forms.Panel panel_shirt;
        private System.Windows.Forms.Button btn_addP3;
        private System.Windows.Forms.Label lb_hargaP3;
        private System.Windows.Forms.Label lb_pants3;
        private System.Windows.Forms.Button btn_addP2;
        private System.Windows.Forms.Label lb_hargaP2;
        private System.Windows.Forms.Label lb_pants2;
        private System.Windows.Forms.Button btn_addP1;
        private System.Windows.Forms.Label lb_hargaP1;
        private System.Windows.Forms.Label lb_pants1;
        private System.Windows.Forms.PictureBox pb_pants3;
        private System.Windows.Forms.PictureBox pb_pants2;
        private System.Windows.Forms.PictureBox pb_pants1;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.Button btn_addLP3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_Lpants3;
        private System.Windows.Forms.Button btn_addLP2;
        private System.Windows.Forms.Label lb_hargaLP2;
        private System.Windows.Forms.Label lb_Lpants2;
        private System.Windows.Forms.Button btn_addLP1;
        private System.Windows.Forms.Label lb_hargaLP1;
        private System.Windows.Forms.Label lb_Lpants1;
        private System.Windows.Forms.PictureBox pb_Lpants3;
        private System.Windows.Forms.PictureBox pb_Lpants1;
        private System.Windows.Forms.PictureBox pb_Lpants2;
        private System.Windows.Forms.Panel panel_Lpants;
        private System.Windows.Forms.Panel panel_shoes;
        private System.Windows.Forms.Button btn_addSh3;
        private System.Windows.Forms.Label lb_hargaSh3;
        private System.Windows.Forms.Label lb_shoes3;
        private System.Windows.Forms.Button btn_addSh2;
        private System.Windows.Forms.Label lb_hargaSh2;
        private System.Windows.Forms.Label lb_shoes2;
        private System.Windows.Forms.Button btn_addSh1;
        private System.Windows.Forms.Label lb_hargaSh1;
        private System.Windows.Forms.Label lb_shoes1;
        private System.Windows.Forms.PictureBox pb_shoe3;
        private System.Windows.Forms.PictureBox pb_shoes2;
        private System.Windows.Forms.PictureBox pb_shoes1;
        private System.Windows.Forms.Panel panel_bracelet;
        private System.Windows.Forms.Button btn_addB3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_bracelet3;
        private System.Windows.Forms.Button btn_addB2;
        private System.Windows.Forms.Label lb_hargaB2;
        private System.Windows.Forms.Label lb_bracelet2;
        private System.Windows.Forms.Button btn_addB1;
        private System.Windows.Forms.Label lb_hargaB1;
        private System.Windows.Forms.Label lb_bracelet1;
        private System.Windows.Forms.PictureBox pb_bracelet3;
        private System.Windows.Forms.PictureBox pb_bracelet2;
        private System.Windows.Forms.PictureBox pb_bracelet1;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Label lb_upload;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.PictureBox pb_upload;
        private System.Windows.Forms.Label lb_item;
        private System.Windows.Forms.Label lb_price;
        private System.Windows.Forms.TextBox tb_itemName;
        private System.Windows.Forms.TextBox tb_price;
        private System.Windows.Forms.Button btn_addUser;
        private System.Windows.Forms.Panel panel_others;
    }
}


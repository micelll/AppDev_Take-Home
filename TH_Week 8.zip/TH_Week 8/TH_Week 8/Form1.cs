﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_Week_8
{
    public partial class Form_Main : Form
    {
        DataTable dtCart = new DataTable();
        public int quantityT1 = 0;
        public int quantityT2 = 0;
        public int quantityT3 = 0;
        public int quantityS1 = 0;
        public int quantityS2 = 0;
        public int quantityS3 = 0;
        public int quantityP1 = 0;
        public int quantityP2 = 0;
        public int quantityP3 = 0;
        public int quantityLP1 = 0;
        public int quantityLP2 = 0;
        public int quantityLP3 = 0;
        public int quantityB1 = 0;
        public int quantityB2 = 0;
        public int quantityB3 = 0;
        public int quantitySh1 = 0;
        public int quantitySh2 = 0;
        public int quantitySh3 = 0;
        public int quantityUser = 0;
        public double total = 0;
        public Form_Main()
        {
            InitializeComponent();
        }

        private void Form_Main_Load(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_Lpants.Visible = false;
            panel_shoes.Visible = false;
            panel_bracelet.Visible = false;
            tb_subtotal.Enabled = false;
            tb_total.Enabled = false;
            panel_others.Visible = false;

            dtCart.Columns.Add("Item Name");
            dtCart.Columns.Add("Quantity");
            dtCart.Columns.Add("Price");
            dtCart.Columns.Add("Total");

            dgv_cart.DataSource = dtCart;
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = true;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_Lpants.Visible = false;
            panel_shoes.Visible = false;
            panel_bracelet.Visible = false;
            panel_others.Visible = false;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_shirt.Visible = true;
            panel_tshirt.Visible = false;
            panel_pants.Visible = false;
            panel_Lpants.Visible = false;
            panel_shoes.Visible = false;
            panel_bracelet.Visible = false;
            panel_others.Visible = false;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_pants.Visible = true;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_Lpants.Visible = false;
            panel_shoes.Visible = false;
            panel_bracelet.Visible = false;
            panel_others.Visible = false;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Lpants.Visible = true;
            panel_pants.Visible = false;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_shoes.Visible = false;
            panel_bracelet.Visible = false;
            panel_others.Visible = false;
        }

        private void btn_addT1_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("T-shirt Kerah Garis Bulat"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityT1 += 1;
                    dtCart.Rows.Add("T-shirt Kerah Garis Bulat", quantityT1, 199000, 199000*quantityT1);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityT1 = 0;
                quantityT1 += 1;
                dtCart.Rows.Add("T-shirt Kerah Garis Bulat", quantityT1, 199000, 199000 * quantityT1);
                for (int i = 0;  i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_shoes.Visible = true;
            panel_Lpants.Visible = false;
            panel_pants.Visible = false;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_bracelet.Visible = false;
            panel_others.Visible = false;
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_bracelet.Visible = true;
            panel_shoes.Visible = false;
            panel_Lpants.Visible = false;
            panel_pants.Visible = false;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_others.Visible = false;
        }

        private void btn_addT2_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("T-shirt Kerut"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityT2 += 1;
                    dtCart.Rows.Add("T-shirt Kerut", quantityT2, 199000, 199000 * quantityT2);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityT2 = 0;
                quantityT2 += 1;
                dtCart.Rows.Add("T-shirt Kerut", quantityT2, 199000, 199000 * quantityT2);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addT3_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("T-shirt Katun"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityT3 += 1;
                    dtCart.Rows.Add("T-shirt Katun", quantityT3, 199000, 199000 * quantityT3);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityT3 = 0;
                quantityT3 += 1;
                dtCart.Rows.Add("T-shirt Katun", quantityT3, 199000, 199000 * quantityT3);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addS1_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Kaos Polo Katun"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityS1 += 1;
                    dtCart.Rows.Add("Kaos Polo Katun", quantityS1, 299000, 299000 * quantityS1);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityS1 = 0;
                quantityS1 += 1;
                dtCart.Rows.Add("Kaos Polo Katun", quantityS1, 299000, 299000 * quantityS1);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addS2_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Kaos Polo Dry"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityS2 += 1;
                    dtCart.Rows.Add("Kaos Polo Dry", quantityS2, 299000, 299000 * quantityS2);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityS2 = 0;
                quantityS2 += 1;
                dtCart.Rows.Add("Kaos Polo Dry", quantityS2, 299000, 299000 * quantityS2);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addS3_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Kaos Polo Rajut"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityS3 += 1;
                    dtCart.Rows.Add("Kaos Polo Rajut", quantityS3, 599000, 599000 * quantityS3);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityS3 = 0;
                quantityS3 += 1;
                dtCart.Rows.Add("Kaos Polo Rajut", quantityS3, 599000, 599000 * quantityS3);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addP1_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Celana Pendek Denim"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityP1 += 1;
                    dtCart.Rows.Add("Celana Pendek Denim", quantityP1, 399000, 399000 * quantityP1);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityP1 = 0;
                quantityP1 += 1;
                dtCart.Rows.Add("Celana Pendek Denim", quantityP1, 399000, 399000 * quantityP1);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dgv_cart.SelectedRows.Count == 0)
            {

            }
            else
            {
                int index = dgv_cart.CurrentCell.RowIndex;
                int price = Convert.ToInt32(dtCart.Rows[index][3]);
                string subtotal = tb_subtotal.Text;
                string hasilSub = subtotal.Substring(3).Replace(",", "").Replace(".", "").Split('.')[0];
                hasilSub = hasilSub.Substring(0, hasilSub.Length - 2);
                tb_subtotal.Text = "Rp " + (Convert.ToInt32(hasilSub) - price).ToString("N");
                int sub = Convert.ToInt32(hasilSub) - price;
                tb_total.Text = "Rp " + ((sub * 0.10) + sub).ToString("N");
                dtCart.Rows.RemoveAt(index);
            }
        }

        private void btn_addP2_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Celana Pendek Cargo"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityP2 += 1;
                    dtCart.Rows.Add("Celana Pendek Cargo", quantityP2, 399000, 399000 * quantityP2);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityP2 = 0;
                quantityP2 += 1;
                dtCart.Rows.Add("Celana Pendek Cargo", quantityP2, 399000, 399000 * quantityP2);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addP3_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Celana Pendek Katun"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityP3 += 1;
                    dtCart.Rows.Add("Celana Pendek Katun", quantityP3, 399000, 399000 * quantityP3);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityP3 = 0;
                quantityP3 += 1;
                dtCart.Rows.Add("Celana Pendek Katun", quantityP3, 399000, 399000 * quantityP3);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addLP1_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Celana Tappered"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityLP1 += 1;
                    dtCart.Rows.Add("Celana Tappered", quantityLP1, 499000, 499000 * quantityLP1);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityLP1 = 0;
                quantityLP1 += 1;
                dtCart.Rows.Add("Celana Tappered", quantityLP1, 499000, 499000 * quantityLP1);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addLP2_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Celana Ankle"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityLP2 += 1;
                    dtCart.Rows.Add("Celana Ankle", quantityLP2, 499000, 499000 * quantityLP2);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityLP2 = 0;
                quantityLP2 += 1;
                dtCart.Rows.Add("Celana Ankle", quantityLP2, 499000, 499000 * quantityLP2);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addLP3_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Celana Lurus"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityLP3 += 1;
                    dtCart.Rows.Add("Celana Lurus", quantityLP3, 399000, 399000 * quantityLP3);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityLP3 = 0;
                quantityLP3 += 1;
                dtCart.Rows.Add("Celana Lurus", quantityLP3, 399000, 399000 * quantityLP3);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addB1_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Pink Bracelet"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityB1 += 1;
                    dtCart.Rows.Add("Pink Bracelet", quantityB1, 500000, 500000 * quantityB1);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityB1 = 0;
                quantityB1 += 1;
                dtCart.Rows.Add("Pink Bracelet", quantityB1, 500000, 500000 * quantityB1);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addB2_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Chain Bracelet"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityB2 += 1;
                    dtCart.Rows.Add("Chain Bracelet", quantityB2, 750000, 750000 * quantityB2);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityB2 = 0;
                quantityB2 += 1;
                dtCart.Rows.Add("Chain Bracelet", quantityB2, 750000, 750000 * quantityB2);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addB3_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Leather Bracelet"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityB3 += 1;
                    dtCart.Rows.Add("Leather Bracelet", quantityB3, 700000, 700000 * quantityB3);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityB3 = 0;
                quantityB3 += 1;
                dtCart.Rows.Add("Leather Bracelet", quantityB3, 700000, 700000 * quantityB3);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addSh1_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Air Jordan"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantitySh1 += 1;
                    dtCart.Rows.Add("Air Jordan", quantitySh1, 2129000, 2129000 * quantitySh1);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantitySh1 = 0;
                quantitySh1 += 1;
                dtCart.Rows.Add("Air Jordan", quantitySh1, 2129000, 2129000 * quantitySh1);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addSh2_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Air Force"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantitySh2 += 1;
                    dtCart.Rows.Add("Air Force", quantitySh2, 1549000, 1549000 * quantitySh2);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantitySh2 = 0;
                quantitySh2 += 1;
                dtCart.Rows.Add("Air Force", quantitySh2, 1549000, 1549000 * quantitySh2);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void btn_addSh3_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains("Air Max"))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantitySh3 += 1;
                    dtCart.Rows.Add("Air Max", quantitySh3, 1499000, 1499000 * quantitySh3);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantitySh3 = 0;
                quantitySh3 += 1;
                dtCart.Rows.Add("Air Max", quantitySh3, 1499000, 1499000 * quantitySh3);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_others.Visible = true;
            panel_bracelet.Visible = false;
            panel_shoes.Visible = false;
            panel_Lpants.Visible = false;
            panel_pants.Visible = false;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            tb_itemName.Enabled = false;
            tb_price.Enabled = false;
            btn_addUser.Enabled = false;
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.jpg, *.jpeg, *.png, *.bmp)|*.jpg;*.jpeg;*.png;*.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pb_upload.Image = Image.FromFile(openFileDialog.FileName);
                pb_upload.SizeMode = PictureBoxSizeMode.StretchImage;
                tb_itemName.Enabled = true;
                tb_price.Enabled = true;
            }
        }

        private void tb_itemName_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemName.Text.Length > 0 && tb_price.Text.Length > 0)
            {
                btn_addUser.Enabled = true;
            }
            else
            {
                btn_addUser.Enabled = false;
            }
        }

        private void tb_price_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemName.Text.Length > 0 && tb_price.Text.Length > 0)
            {
                btn_addUser.Enabled = true;
            }
            else
            {
                btn_addUser.Enabled = false;
            }
        }

        private void tb_price_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void btn_addUser_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            int price = Convert.ToInt32(tb_price.Text);
            bool cek = false;
            foreach (DataRow rows in dtCart.Rows)
            {
                if (rows[0].ToString().Contains(tb_itemName.Text))
                {
                    dtCart.Rows.Remove(rows);
                    cek = true;
                    quantityUser += 1;
                    dtCart.Rows.Add(tb_itemName.Text, quantityUser, price, price * quantityUser);
                    for (int i = 0; i < dtCart.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                quantityUser = 0;
                quantityUser += 1;
                dtCart.Rows.Add(tb_itemName.Text, quantityUser, price, price * quantityUser);
                for (int i = 0; i < dtCart.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtCart.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_cart.ClearSelection();
            pb_upload.Image = null;
            tb_itemName.Clear();
            tb_price.Clear();
        }
    }
}
